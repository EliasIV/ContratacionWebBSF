function busqueda(){
	
	var CentroLogistico = document.getElementById("cmbx_Centro_Logistico").value;
	var Bodega = document.getElementById("cmbx_Bodega").value;

	var parametros = {
		"CentroLogistico" : CentroLogistico,
		"Bodega" : Bodega

	};

	$.ajax({
		data: parametros,
		url: "Ajax/getM2Bodega.php",
		type: "POST",
		success: function(response){
				$("#datos").html(response);
		}
		

	});

}