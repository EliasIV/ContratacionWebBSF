// Capturando el DIV alerta y mensaje
var alerta = document.getElementById("alerta");
var mensaje = document.getElementById("mensaje");

var alertaContable = document.getElementById("alertaContable");
var mensajeContable = document.getElementById("mensajeContable");

var alertaComercial = document.getElementById("alertaComercial");
var mensajeComercial = document.getElementById("mensajeComercial");

var alertaBodega = document.getElementById("alertaBodega");
var mensajeBodega = document.getElementById("mensajeBodega");

var alertaDuplicado = document.getElementById("alertaDuplicado");
var mensajeDuplicado = document.getElementById("mensajeDuplicado");


// Permitir sólo números en el imput
function isNumber(evt) {
  var charCode = evt.which ? evt.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode === 75) return false;

  return true;
}


//////////////////////////////////////////// LEGAL ////////////////////////////////////////
function checkRut(rut) {
	
	$(document).ready(function() {
		$("#mensaje").show();
	});
	
	

  if (rut.value.length <= 1) {
    //alerta.classList.remove('alert-success', 'alert-danger');
    //alerta.classList.add('alert-info');
    mensaje.innerHTML = 'Ingrese un RUT en el siguiente campo de texto para validar si es correcto o no';
  }

  // Obtiene el valor ingresado quitando puntos y guión.
  var valor = clean(rut.value);

  // Divide el valor ingresado en dígito verificador y resto del RUT.
  cuerpo = valor.slice(0, -1);
  dv = valor.slice(-1).toUpperCase();

  // Separa con un Guión el cuerpo del dígito verificador.
  rut.value = format(rut.value);

  // Si no cumple con el mínimo ej. (n.nnn.nnn)
  if (cuerpo.length < 7) {
    rut.setCustomValidity("RUT Incompleto");
    //alerta.classList.remove('alert-success', 'alert-danger');
    //alerta.classList.add('alert-info');
    //mensaje.innerHTML = 'Ingresó un RUT muy corto, el RUT debe ser mayor a 7 Dígitos. Ej: x.xxx.xxx-x';
	mensaje.innerHTML = 'Incorrecto';
	mensaje.style = "color: #CB3234;";
    return false;
  }

  // Calcular Dígito Verificador "Método del Módulo 11"
  suma = 0;
  multiplo = 2;

  // Para cada dígito del Cuerpo
  for (i = 1; i <= cuerpo.length; i++) {
    // Obtener su Producto con el Múltiplo Correspondiente
    index = multiplo * valor.charAt(cuerpo.length - i);

    // Sumar al Contador General
    suma = suma + index;

    // Consolidar Múltiplo dentro del rango [2,7]
    if (multiplo < 7) {
      multiplo = multiplo + 1;
    } else {
      multiplo = 2;
    }
  }

  // Calcular Dígito Verificador en base al Módulo 11
  dvEsperado = 11 - (suma % 11);

  // Casos Especiales (0 y K)
  dv = dv == "K" ? 10 : dv;
  dv = dv == 0 ? 11 : dv;

  // Validar que el Cuerpo coincide con su Dígito Verificador
  if (dvEsperado != dv) {
    rut.setCustomValidity("RUT Inválido");

    //alerta.classList.remove('alert-info', 'alert-success');
    //alerta.classList.add('alert-danger');
    //mensaje.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>INCORRECTO</strong>.';
	mensaje.innerHTML = 'Incorrecto';
	mensaje.style = "color: #CB3234;";

    return false;
  } else {
    rut.setCustomValidity("RUT Válido");

    //alerta.classList.remove('d-none', 'alert-danger');
    //alerta.classList.add('alert-success');
    //mensaje.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>CORRECTO</strong>.';
	mensaje.style = "color: #008f39;";
	mensaje.innerHTML = 'Válido';
	
	
	$(document).ready(function() {
		setTimeout(function() {
		$("#mensaje").fadeOut(400);
		},400);
	});
	
    return true;
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////CONTABLE/////////////////////////////////////////////////////////////


function checkRutContable(rut) {
	
	$(document).ready(function() {
		$("#mensajeContable").show();
	});
	

  if (rut.value.length <= 1) {
    //alertaContable.classList.remove('alert-success', 'alert-danger');
    //alertaContable.classList.add('alert-info');
    mensajeContable.innerHTML = 'Ingrese un RUT en el siguiente campo de texto para validar si es correcto o no';
  }

  // Obtiene el valor ingresado quitando puntos y guión.
  var valor = clean(rut.value);

  // Divide el valor ingresado en dígito verificador y resto del RUT.
  cuerpo = valor.slice(0, -1);
  dv = valor.slice(-1).toUpperCase();

  // Separa con un Guión el cuerpo del dígito verificador.
  rut.value = format(rut.value);

  // Si no cumple con el mínimo ej. (n.nnn.nnn)
  if (cuerpo.length < 7) {
    rut.setCustomValidity("RUT Incompleto");
    //alertaContable.classList.remove('alert-success', 'alert-danger');
    //alertaContable.classList.add('alert-info');
    //mensajeContable.innerHTML = 'Ingresó un RUT muy corto, el RUT debe ser mayor a 7 Dígitos. Ej: x.xxx.xxx-x';
	mensajeContable.innerHTML = 'Incorrecto';
	mensajeContable.style = "color: #CB3234;";
    return false;
  }

  // Calcular Dígito Verificador "Método del Módulo 11"
  suma = 0;
  multiplo = 2;

  // Para cada dígito del Cuerpo
  for (i = 1; i <= cuerpo.length; i++) {
    // Obtener su Producto con el Múltiplo Correspondiente
    index = multiplo * valor.charAt(cuerpo.length - i);

    // Sumar al Contador General
    suma = suma + index;

    // Consolidar Múltiplo dentro del rango [2,7]
    if (multiplo < 7) {
      multiplo = multiplo + 1;
    } else {
      multiplo = 2;
    }
  }

  // Calcular Dígito Verificador en base al Módulo 11
  dvEsperado = 11 - (suma % 11);

  // Casos Especiales (0 y K)
  dv = dv == "K" ? 10 : dv;
  dv = dv == 0 ? 11 : dv;

  // Validar que el Cuerpo coincide con su Dígito Verificador
  if (dvEsperado != dv) {
    rut.setCustomValidity("RUT Inválido");

    //alertaContable.classList.remove('alert-info', 'alert-success');
    //alertaContable.classList.add('alert-danger');
    //mensajeContable.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>INCORRECTO</strong>.';
	mensajeContable.innerHTML = 'Incorrecto';
	mensajeContable.style = "color: #CB3234;";

    return false;
  } else {
    rut.setCustomValidity("RUT Válido");

    //alertaContable.classList.remove('d-none', 'alert-danger');
    //alertaContable.classList.add('alert-success');
    //mensajeContable.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>CORRECTO</strong>.';
	
	mensajeContable.style = "color: #008f39;";
	mensajeContable.innerHTML = 'Válido';
	
	
	$(document).ready(function() {
		setTimeout(function() {
		$("#mensajeContable").fadeOut(400);
		},400);
	});
	
	
	
    return true;
  }
}


///////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////COMERCIAL ///////////////////////////////////////////

function checkRutComercial(rut) {
	
	//alert(rut);
	
	$(document).ready(function() {
		$("#mensajeComercial").show();
	});


  if (rut.value.length <= 1) {
   // alertaComercial.classList.remove('alert-success', 'alert-danger');
   //alertaComercial.classList.add('alert-info');
    mensajeComercial.innerHTML = '';
  }

  // Obtiene el valor ingresado quitando puntos y guión.
  var valor = clean(rut.value);

  // Divide el valor ingresado en dígito verificador y resto del RUT.
  cuerpo = valor.slice(0, -1);
  dv = valor.slice(-1).toUpperCase();

  // Separa con un Guión el cuerpo del dígito verificador.
  rut.value = format(rut.value);

  // Si no cumple con el mínimo ej. (n.nnn.nnn)
  if (cuerpo.length < 7) {
    rut.setCustomValidity("RUT Incompleto");
    //alertaComercial.classList.remove('alert-success', 'alert-danger');
    //alertaComercial.classList.add('alert-info');
    //mensajeComercial.innerHTML = 'Ingresó un RUT muy corto, el RUT debe ser mayor a 7 Dígitos. Ej: x.xxx.xxx-x';
	mensajeComercial.innerHTML = 'Incorrecto';
	mensajeComercial.style = "color: #CB3234;";
    return false;
  }

  // Calcular Dígito Verificador "Método del Módulo 11"
  suma = 0;
  multiplo = 2;

  // Para cada dígito del Cuerpo
  for (i = 1; i <= cuerpo.length; i++) {
    // Obtener su Producto con el Múltiplo Correspondiente
    index = multiplo * valor.charAt(cuerpo.length - i);

    // Sumar al Contador General
    suma = suma + index;

    // Consolidar Múltiplo dentro del rango [2,7]
    if (multiplo < 7) {
      multiplo = multiplo + 1;
    } else {
      multiplo = 2;
    }
  }

  // Calcular Dígito Verificador en base al Módulo 11
  dvEsperado = 11 - (suma % 11);

  // Casos Especiales (0 y K)
  dv = dv == "K" ? 10 : dv;
  dv = dv == 0 ? 11 : dv;

  // Validar que el Cuerpo coincide con su Dígito Verificador
  if (dvEsperado != dv) {
    rut.setCustomValidity("RUT Inválido");

    //alertaComercial.classList.remove('alert-info', 'alert-success');
    //alertaComercial.classList.add('alert-danger');
    //mensajeComercial.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>INCORRECTO</strong>.';
	mensajeComercial.innerHTML = 'Incorrecto';
	mensajeComercial.style = "color: #CB3234;";

    return false;
  } else {
    rut.setCustomValidity("RUT Válido");

    //alertaComercial.classList.remove('d-none', 'alert-danger');
    //alertaComercial.classList.add('alert-success');
    //mensajeComercial.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>CORRECTO</strong>.';
	
	mensajeComercial.style = "color: #008f39;";
	mensajeComercial.innerHTML = 'Válido';
	
	
	$(document).ready(function() {
		setTimeout(function() {
		$("#mensajeComercial").fadeOut(400);
		},400);
	});
	
    return true;
  }
}


///////////////////////////////////////////////////////////////////////////////////////////






//////////////////////////////////////BODEGA ///////////////////////////////////////////

function checkRutBodega(rut) {
	
	$(document).ready(function() {
		$("#mensajeBodega").show();
	});

	
	
	//alert(rut);

  if (rut.value.length <= 1) {
    //alertaBodega.classList.remove('alert-success', 'alert-danger');
    //alertaBodega.classList.add('alert-info');
    //mensajeBodega.innerHTML = 'Ingrese un RUT en el siguiente campo de texto para validar si es correcto o no';
	mensajeBodega.innerHTML = '';
  }

  // Obtiene el valor ingresado quitando puntos y guión.
  var valor = clean(rut.value);

  // Divide el valor ingresado en dígito verificador y resto del RUT.
  cuerpo = valor.slice(0, -1);
  dv = valor.slice(-1).toUpperCase();

  // Separa con un Guión el cuerpo del dígito verificador.
  rut.value = format(rut.value);

  // Si no cumple con el mínimo ej. (n.nnn.nnn)
  if (cuerpo.length < 7) {
    rut.setCustomValidity("RUT Incompleto");
    //alertaBodega.classList.remove('alert-success', 'alert-danger');
    //alertaBodega.classList.add('alert-info');
    //mensajeBodega.innerHTML = 'Ingresó un RUT muy corto, el RUT debe ser mayor a 7 Dígitos. Ej: x.xxx.xxx-x';
	mensajeBodega.style = "color: #CB3234;";
	mensajeBodega.innerHTML = 'Incorrecto';
	
	
    return false;
  }

  // Calcular Dígito Verificador "Método del Módulo 11"
  suma = 0;
  multiplo = 2;

  // Para cada dígito del Cuerpo
  for (i = 1; i <= cuerpo.length; i++) {
    // Obtener su Producto con el Múltiplo Correspondiente
    index = multiplo * valor.charAt(cuerpo.length - i);

    // Sumar al Contador General
    suma = suma + index;

    // Consolidar Múltiplo dentro del rango [2,7]
    if (multiplo < 7) {
      multiplo = multiplo + 1;
    } else {
      multiplo = 2;
    }
  }

  // Calcular Dígito Verificador en base al Módulo 11
  dvEsperado = 11 - (suma % 11);

  // Casos Especiales (0 y K)
  dv = dv == "K" ? 10 : dv;
  dv = dv == 0 ? 11 : dv;

  // Validar que el Cuerpo coincide con su Dígito Verificador
  if (dvEsperado != dv) {
    rut.setCustomValidity("RUT Inválido");

    //alertaBodega.classList.remove('alert-info', 'alert-success');
    //alertaBodega.classList.add('alert-danger');
    //mensajeBodega.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>INCORRECTO</strong>.';
	mensajeBodega.style = "color: #CB3234;";
	mensajeBodega.innerHTML = 'Incorrecto';
	
    return false;
  } else {
    rut.setCustomValidity("RUT Válido");

    //alertaBodega.classList.remove('d-none', 'alert-danger');
    //alertaBodega.classList.add('alert-success');
    //mensajeBodega.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>CORRECTO</strong>.';
	
	mensajeBodega.style = "color: #008f39;";
	mensajeBodega.innerHTML = 'Válido';
	
	
	$(document).ready(function() {
		setTimeout(function() {
		$("#mensajeBodega").fadeOut(400);
		},400);
	});
	
    return true;
  }
}


///////////////////////////////////////////////////////////////////////////////////////////




//////////////////////////////////////DUPLICADO ///////////////////////////////////////////

function checkRutDuplicado(rut) {
	
	//alert(rut);

  if (rut.value.length <= 1) {
    alertaDuplicado.classList.remove('alert-success', 'alert-danger');
    alertaDuplicado.classList.add('alert-info');
    mensajeDuplicado.innerHTML = 'Ingrese un RUT en el siguiente campo de texto para validar si es correcto o no';
  }

  // Obtiene el valor ingresado quitando puntos y guión.
  var valor = clean(rut.value);

  // Divide el valor ingresado en dígito verificador y resto del RUT.
  cuerpo = valor.slice(0, -1);
  dv = valor.slice(-1).toUpperCase();

  // Separa con un Guión el cuerpo del dígito verificador.
  rut.value = format(rut.value);

  // Si no cumple con el mínimo ej. (n.nnn.nnn)
  if (cuerpo.length < 7) {
    rut.setCustomValidity("RUT Incompleto");
    alertaDuplicado.classList.remove('alert-success', 'alert-danger');
    alertaDuplicado.classList.add('alert-info');
    mensajeDuplicado.innerHTML = 'Ingresó un RUT muy corto, el RUT debe ser mayor a 7 Dígitos. Ej: x.xxx.xxx-x';
    return false;
  }

  // Calcular Dígito Verificador "Método del Módulo 11"
  suma = 0;
  multiplo = 2;

  // Para cada dígito del Cuerpo
  for (i = 1; i <= cuerpo.length; i++) {
    // Obtener su Producto con el Múltiplo Correspondiente
    index = multiplo * valor.charAt(cuerpo.length - i);

    // Sumar al Contador General
    suma = suma + index;

    // Consolidar Múltiplo dentro del rango [2,7]
    if (multiplo < 7) {
      multiplo = multiplo + 1;
    } else {
      multiplo = 2;
    }
  }

  // Calcular Dígito Verificador en base al Módulo 11
  dvEsperado = 11 - (suma % 11);

  // Casos Especiales (0 y K)
  dv = dv == "K" ? 10 : dv;
  dv = dv == 0 ? 11 : dv;

  // Validar que el Cuerpo coincide con su Dígito Verificador
  if (dvEsperado != dv) {
    rut.setCustomValidity("RUT Inválido");

    alertaDuplicado.classList.remove('alert-info', 'alert-success');
    alertaDuplicado.classList.add('alert-danger');
    mensajeDuplicado.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>INCORRECTO</strong>.';

    return false;
  } else {
    rut.setCustomValidity("RUT Válido");

    alertaDuplicado.classList.remove('d-none', 'alert-danger');
    alertaDuplicado.classList.add('alert-success');
    mensajeDuplicado.innerHTML = 'El RUT ingresado: ' + rut.value + ' Es <strong>CORRECTO</strong>.';
    return true;
  }
}


///////////////////////////////////////////////////////////////////////////////////////////




function format (rut) {
  rut = clean(rut)

  var result = rut.slice(-4, -1) + '-' + rut.substr(rut.length - 1)
  for (var i = 4; i < rut.length; i += 3) {
    result = rut.slice(-3 - i, -i) + '.' + result
  }

  return result
}

function clean (rut) {
  return typeof rut === 'string'
    ? rut.replace(/^0+|[^0-9kK]+/g, '').toUpperCase()
    : ''
}