<?php
	
	error_reporting(E_ALL ^ E_NOTICE);
	
	$serverName="BDBSF\BDBSF";
	$connectionInfo = array("Database"=> "BSFCotizaciones", "UID"=>"sa", "PWD"=>"m@sterkey", "CharacterSet"=>"UTF-8");


	$con7 = sqlsrv_connect($serverName, $connectionInfo);
	
	if ($con7)
	{
		#echo"Conexion Exitosa";
	} else {
		echo"Fallo en la conexion";
		die(print_r(sqlsrv_errors(), true ));
	}
	

    $salida = "";

    #$query = "SELECT TOP 3 CODIGO, DETALLE, UNIDAD, M2, CANTIDAD, VAL_UNI_UF, (CANTIDAD * VAL_UNI_UF) as TOTAL_UF FROM DETCOTIZA ORDER BY NROCOTIZ DESC";

    if (isset($_POST['consulta'])) {
    	#$q = $con7->ms_escape_string($_POST['consulta']);
		#$q = $conn->real_escape_string($_POST['consulta']);
		$q= $_POST['consulta'];
    	#$query = "SELECT * FROM jugadores WHERE Id_no LIKE '%$q%' OR Name LIKE '%$q%' OR ClubName LIKE '%$q%' OR Rtg_Nat LIKE '%$q%' OR Title LIKE '$q' ";
		#$query = "SELECT CODIGO, DETALLE, UNIDAD, M2, CANTIDAD, VAL_UNI_UF, (CANTIDAD * VAL_UNI_UF) as TOTAL_UF FROM DETCOTIZA WHERE NROCOTIZ = $q ORDER BY NROCOTIZ DESC";
		
		$query = " SELECT CODIGO, DETALLE, UNIDAD, CONVERT (FLOAT, ROUND (M2,2 , 1)) AS M2, CONVERT (FLOAT, ROUND (CANTIDAD, 2, 1)) AS CANTIDAD, 
				   CONVERT (FLOAT, ROUND (VAL_UNI_UF, 3, 1)) as VAL_UNI_UF, 
 				   CONVERT(FLOAT, ROUND ((CANTIDAD * VAL_UNI_UF),2,1)) as TOTAL_UF 
				   FROM DETCOTIZA 
				   WHERE NROCOTIZ =  $q 
				   ORDER BY NROCOTIZ DESC ";
		
    }

    #$resultado = $conn->query($query);
	$resultado = sqlsrv_query($con7, $query);

	$row_count = sqlsrv_num_fields ($resultado);

    if ($row_count >0) {
    	$salida.="<table border=1 class='table table-bordered table-hover' >
    			<thead>
    				<tr id='titulo'>
    					<td>CÓDIGO</td>
    					<td>DESCRIPCIÓN</td>
    					<td>UNIDAD</td>
    					<td>M2</td>
    					<td>CANTIDAD</td>
						<td>VALOR UNITARIO UF</td>
						<td>TOTAL UF</td>
    				</tr>

    			</thead>
    			

    	<tbody>";

    	#while ($fila = $resultado->fetch_assoc()) {
			while($fila= sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)){
    		$salida.="<tr>
    					<td>".$fila['CODIGO']."</td>
    					<td>".$fila['DETALLE']."</td>
    					<td>".$fila['UNIDAD']."</td>
    					<td>".$fila['M2']."</td>
    					<td>".$fila['CANTIDAD']."</td>
						<td>".$fila['VAL_UNI_UF']."</td>
						<td>".$fila['TOTAL_UF']."</td>	
    				</tr>";
    	}
    	$salida.="</tbody></table>";
    }else{
    	#$salida.="SELECCIONA LA COTIZACIÓN , QUE DESEE SABER LOS ADICIONALES";
		
		$salida.="<table border=1 class='table table-bordered table-hover' >
    			<thead>
    				<tr id='titulo'>
    					<td>CODIGO</td>
    					<td>DESCRICION</td>
    					<td>UNIDAD</td>
    					<td>M2</td>
    					<td>CANTIDAD</td>
						<td>VALOR UNITARIO UF</td>
						<td>TOTAL UF</td>
    				</tr>
					
					<tr >
    					<td></td>
    					<td></td>
    					<td></td>
    					<td></td>
    					<td></td>
						<td></td>
						<td></td>
    				</tr>
					
					<tr >
    					<td></td>
    					<td></td>
    					<td></td>
    					<td></td>
    					<td></td>
						<td></td>
						<td></td>
    				</tr>
					
					
					<tr >
    					<td></td>
    					<td></td>
    					<td></td>
    					<td></td>
    					<td></td>
						<td></td>
						<td></td>
    				</tr>
					
					
					
					

    			</thead>
    			

    	<tbody>";
		
    }

    echo $salida;
	
	sqlsrv_close($con7);
?>