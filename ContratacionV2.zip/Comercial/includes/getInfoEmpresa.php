<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$valor1 = $_POST['RutEmpresa']; 
	$valor2=$_POST['DV']; 

	$MyQuerry = "SELECT NROCOTIZ, EMPRESA FROM MAECOTIZA Where RUT_EMPRESA = '$valor1' and DV_EMPRESA = '$valor2' ORDER BY ID DESC ";
	
	$resultado = sqlsrv_query($con7, $MyQuerry);
	
	while($valores3= sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)){
	
	$NumCotiza = $valores3['NROCOTIZ'];
	$NombreEmpresa = $valores3['EMPRESA'];
	}

	echo $NumCotiza;
	echo "-";
	echo $NombreEmpresa;
	
?>