<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Rut_Empresa=$_POST['Rut_Empresa'];
	
	$Nro_Cotizacion=$_POST['Nro_Cotizacion'];

	#$Rut_Empresa = '9906771';
	
	$MyQuerryCotizacion_Telefono = "SELECT top 1 TELEFONO, ID FROM MAECOTIZA WHERE RUT_EMPRESA = '$Rut_Empresa' and ESTADO = 1 and NROCOTIZ = $Nro_Cotizacion ";
	
	$resultadoCotizacion_Telefono = sqlsrv_query($con7, $MyQuerryCotizacion_Telefono);
	
	#$htmlCotizacion_Telefono = "<option value='0'> Seleccione el telefono </option> ";
	
	while($rowCotizacion_Telefono = sqlsrv_fetch_array($resultadoCotizacion_Telefono, SQLSRV_FETCH_ASSOC)){
	
	$Id_Telefono_Cotiza = $rowCotizacion_Telefono['ID'];
	$Telefono_Contacto_Cotiza = $rowCotizacion_Telefono['TELEFONO'];
	
	$htmlCotizacion_Telefono = '<option value = "'.$Id_Telefono_Cotiza.'" > '.$Telefono_Contacto_Cotiza.' </option>';
	
	}
	
	echo $htmlCotizacion_Telefono;
		
?>