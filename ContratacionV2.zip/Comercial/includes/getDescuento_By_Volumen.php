<?php

include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Cotizacion=$_POST['Nro_Cotizacion'];

	#$Cotizacion =8726;

	$MyQuerryDescuentoByVolumen = " select DES_POR_VOL from [dbo].[DETCOTIZA] where NROCOTIZ = $Cotizacion; ";
	
	$resultadoDescuentoByVolumen = sqlsrv_query($con7, $MyQuerryDescuentoByVolumen);
	
	while($valoresDescuentoByVolumen = sqlsrv_fetch_array($resultadoDescuentoByVolumen, SQLSRV_FETCH_ASSOC)){
	
	$TotalM2 = $valoresDescuentoByVolumen['DES_POR_VOL'];
	
	$htmlDescuentoByVolumen = $TotalM2;

	}
	
	echo $htmlDescuentoByVolumen;




?>