<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Rut_Empresa=$_POST['Rut_Empresa'];
	
	$Nro_Cotizacion=$_POST['Nro_Cotizacion'];

	#$Rut_Empresa = '9906771';
	
	$MyQuerryCotizacion_Fax = "SELECT top 1 FAX, ID FROM MAECOTIZA WHERE RUT_EMPRESA = '$Rut_Empresa' and ESTADO = 1 and NROCOTIZ = $Nro_Cotizacion ";
	
	$resultadoCotizacion_Fax = sqlsrv_query($con7, $MyQuerryCotizacion_Fax);
	
	#$htmlCotizacion_Fax = "<option value='0'> Seleccione el fax </option> ";
	
	while($rowCotizacion_Fax = sqlsrv_fetch_array($resultadoCotizacion_Fax, SQLSRV_FETCH_ASSOC)){
	
	$Id_Fax_Cotiza = $rowCotizacion_Fax['ID'];
	$Fax_Contacto_Cotiza = $rowCotizacion_Fax['FAX'];
	
	$htmlCotizacion_Fax = '<option value = "'.$Id_Fax_Cotiza.'" > '.$Fax_Contacto_Cotiza.' </option>';
	
	}
	
	echo $htmlCotizacion_Fax;
		
?>