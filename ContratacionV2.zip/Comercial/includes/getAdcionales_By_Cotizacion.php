<?php

	$serverName="BDBSF\BDBSF";
	$connectionInfo = array("Database"=> "BSFCotizaciones", "UID"=>"sa", "PWD"=>"m@sterkey", "CharacterSet"=>"UTF-8");
	$con7 = sqlsrv_connect($serverName, $connectionInfo);
	
	$MyQuerry = " SELECT CODIGO, DETALLE, UNIDAD, M2, CANTIDAD, VAL_UNI_UF, (CANTIDAD * VAL_UNI_UF) as TOTAL_UF FROM DETCOTIZA WHERE (NROCOTIZ = 5321) ORDER BY DES_PTO_PGO DESC ";
	$resultado = sqlsrv_query($con7, $MyQuerry);
	
	if(!$resultado){
		die("Error");
	} else {
		while ($valores= sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC) ) {
			$arreglo["data"][] = $valores;
		}
		
		echo json_encode($arreglo);
		
	}
	


?>