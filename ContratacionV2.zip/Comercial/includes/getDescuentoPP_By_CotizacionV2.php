<?php

include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Cotizacion=$_POST['Cotizacion'];

	#$Cotizacion =8622;

	$MyQuerryDescto = " select DES_PTO_PGO from [dbo].[DETCOTIZA] where NROCOTIZ = $Cotizacion; ";
	
	$resultadoDescto = sqlsrv_query($con7, $MyQuerryDescto);
	
	while($valoresDescto = sqlsrv_fetch_array($resultadoDescto, SQLSRV_FETCH_ASSOC)){
	
	$TotalM2 = $valoresDescto['DES_PTO_PGO'];
	
	$htmlDescto = $TotalM2;

	}
	
	echo $htmlDescto;




?>