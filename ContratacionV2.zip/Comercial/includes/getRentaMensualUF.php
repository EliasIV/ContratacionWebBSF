<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Cotizacion=$_POST['Cotizacion'];

	#$Cotizacion =5321;
	
	#$MyQuerryRenta = "SELECT SUM(CANTIDAD * VAL_UNI_UF) as TOTAL_UF FROM DETCOTIZA WHERE (NROCOTIZ = $Cotizacion)"; 
	
	$MyQuerryRenta = "select SUM(CONVERT(FLOAT, ROUND (CANTIDAD, 2, 1)) * CONVERT(FLOAT , ROUND (VAL_UNI_UF,2,1))) as TOTAL_UF FROM DETCOTIZA WHERE (NROCOTIZ = $Cotizacion)";
	
	 #$CONVERT (FLOAT, ROUND(DES_PTO_PGO , 2 ,1))
	
	
	$resultadoRenta = sqlsrv_query($con7, $MyQuerryRenta);
	
	#$htmlComuna = "<option value='0'> Seleccione la Comuna </option> ";

	while($valoresRenta = sqlsrv_fetch_array($resultadoRenta, SQLSRV_FETCH_ASSOC)){
			
	$htmlRenta = $valoresRenta['TOTAL_UF'];

	}
	echo $htmlRenta;
?>