<?php

include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Cotizacion=$_POST['Nro_Cotizacion'];

	#$Cotizacion =8726;

	$MyQuerryPlazoRenovacion = " select PERIODO From MAECOTIZA where NROCOTIZ = $Cotizacion; ";
	
	$resultadoPlazoRenovacion = sqlsrv_query($con7, $MyQuerryPlazoRenovacion);
	
	while($valoresPlazoRenovacion = sqlsrv_fetch_array($resultadoPlazoRenovacion, SQLSRV_FETCH_ASSOC)){
	
	$TotalM2 = $valoresPlazoRenovacion['PERIODO'];
	
	$htmlPlazoRenovacion = $TotalM2;

	}
	
	echo $htmlPlazoRenovacion;




?>