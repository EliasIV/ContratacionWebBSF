<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Cotizacion=$_POST['Cotizacion'];

	#$Cotizacion =8556;

	$MyQuerryCentroLogistico2 = " select Distinct (det.CENTRO), cent.CEN_NOMBRE  From DETCOTIZA det , BSFAdministracion.dbo.CENTROS cent where det.NROCOTIZ = $Cotizacion and cent.CEN_CODIGO = det.CENTRO ";
	
	$resultadoCentroLogistico2 = sqlsrv_query($con7, $MyQuerryCentroLogistico2);
	
	$htmlCentroLogistico2 = "<option value='0'> Seleccione el Centro Logistico </option> ";

	while($valoresCentroLogistico2 = sqlsrv_fetch_array($resultadoCentroLogistico2, SQLSRV_FETCH_ASSOC)){
	
	$codigoCentroLogistico2 = $valoresCentroLogistico2['CENTRO'];
	$nombreCentroLogistico2 = $valoresCentroLogistico2['CEN_NOMBRE'];


	#$html= '<option value = "'.$codigo3.'" > '.$nombre3.' </option>';
	
	$htmlCentroLogistico2.= "<option value = '".$codigoCentroLogistico2."' > ".$nombreCentroLogistico2." </option>";

	#echo $htmlBodegas;

	}
	
	echo $htmlCentroLogistico2;

	#echo $html;
?>