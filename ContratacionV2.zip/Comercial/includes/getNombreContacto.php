<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Rut_Empresa=$_POST['Rut_Empresa'];
	
	$Nro_Cotizacion=$_POST['Nro_Cotizacion'];

	#$Rut_Empresa = '9906771';
	
	$MyQuerryCotizacion_Contacto = "SELECT top 1 ATENCION, ID FROM MAECOTIZA WHERE RUT_EMPRESA = '$Rut_Empresa' and ESTADO = 1 and NROCOTIZ = $Nro_Cotizacion ";
	
	$resultadoCotizacion_Contacto = sqlsrv_query($con7, $MyQuerryCotizacion_Contacto);
	
	#$htmlCotizacion_Contacto = "<option value='0'> Seleccione el contacto </option> ";
	
	while($rowCotizacion_Contacto= sqlsrv_fetch_array($resultadoCotizacion_Contacto, SQLSRV_FETCH_ASSOC)){
	
	$Id_Contacto_Cotiza = $rowCotizacion_Contacto['ID'];
	$Nombre_Contacto_Cotiza = $rowCotizacion_Contacto['ATENCION'];
	
	$htmlCotizacion_Contacto = '<option value = "'.$Id_Contacto_Cotiza.'" > '.$Nombre_Contacto_Cotiza.' </option>';
	
	}
	
	echo $htmlCotizacion_Contacto;
		
?>