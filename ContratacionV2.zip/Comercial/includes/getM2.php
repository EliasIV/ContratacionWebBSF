<?php
	include("../../Conexion/conexion_sql_server_7.php");

	$BODE_NROBODEGA=$_POST['BODE_NROBODEGA'];
	
	$Centro = $_POST['valor'];
	
	#$BODE_NROBODEGA='0204';
	
	#$BODE_CENTRO=$_POST['BODE_NROBODEGA'];

	

	#$CEN_CODIGO=$_POST['CEN_CODIGO'];

	#$CEN_CODIGO ="KCH";

	$agno = date("Y"); 
	$mes= date("m");
							
	$agno2 = substr(date("Y") , -2);

	$conc = $mes.$agno2;

	#and BODE_CENTRO='$CEN_CODIGO'
	#$MyQuerry3 = "select BODE_GRUPO, BODE_NROBODEGA, BODE_TBODEGA, BODE_TOTM2, BODE_VALM2, BODE_RENTAUF from BODE$conc where BODE_NROBODEGA = '$BODE_NROBODEGA' and BODE_CENTRO = '$BODE_CENTRO' order by BODE_NROBODEGA";
	
	#$MyQuerry3 = "select BODE_GRUPO, BODE_NROBODEGA, BODE_TBODEGA, BODE_TOTM2, BODE_VALM2, BODE_RENTAUF from BODE$conc where BODE_NROBODEGA = '$BODE_NROBODEGA' order by BODE_NROBODEGA";
	
	#and BODE_CENTRO = '$Centro'
	
	$MyQuerryM2 = " select BODE_GRUPO, BODE_NROBODEGA, BODE_TBODEGA, CONVERT( FLOAT, ROUND(BODE_TOTM2 , 2, 1)) as TOTAL_M2, BODE_VALM2, BODE_RENTAUF  from BODE$conc where BODE_NROBODEGA = '$BODE_NROBODEGA' and BODE_CENTRO = '$Centro' order by BODE_NROBODEGA ";
	
	
	$resultadoM2 = sqlsrv_query($con7, $MyQuerryM2);
	
	#$htmlM2= "<option value='0'> Seleccione la opcion </option> ";

	while($valoresM2= sqlsrv_fetch_array($resultadoM2, SQLSRV_FETCH_ASSOC)){
	
	$codigoM2 = $valoresM2['TOTAL_M2'];
	$nombreM2 = $valoresM2['TOTAL_M2'];


	$htmlM2.= '<option value = "'.$codigoM2.'" > '.$nombreM2.' </option>';

	#echo $htmlM2;

	}

	echo $htmlM2;
	
?>