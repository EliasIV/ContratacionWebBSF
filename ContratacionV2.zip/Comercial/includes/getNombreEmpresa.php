<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Rut_Empresa=$_POST['Rut_Empresa'];
	
	#$Rut_Empresa='76266338';

	$MyQuerryNombre = " SELECT  top 1 EMPRESA , RUT_EMPRESA, DV_EMPRESA FROM MAECOTIZA WHERE (RUT_EMPRESA <> 0) and RUT_EMPRESA = '$Rut_Empresa' ";
		
	$resultadoNombre = sqlsrv_query($con7, $MyQuerryNombre);
	
	#$htmlNombre = "<option value='0'> Seleccione la empresa </option> ";

	while($rowNombre= sqlsrv_fetch_array($resultadoNombre, SQLSRV_FETCH_ASSOC)){
	
	$rut = $rowNombre['RUT_EMPRESA'];
	$nombre = $rowNombre['EMPRESA'];

	$htmlNombre = '<option value = "'.$rut.'" > '.$nombre.' </option>';
	
	}
	
	echo $htmlNombre;
	

	
?>