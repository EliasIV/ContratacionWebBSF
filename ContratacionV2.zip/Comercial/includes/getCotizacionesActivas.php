<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Rut_Empresa=$_POST['Rut_Empresa'];

	#$Rut_Empresa = '9906771';
	
	$MyQuerryCotizacion = "SELECT NROCOTIZ FROM MAECOTIZA WHERE RUT_EMPRESA = '$Rut_Empresa' and ESTADO = 1";
	
	$resultadoCotizacion = sqlsrv_query($con7, $MyQuerryCotizacion);
	
	$htmlCotizacion = "<option value='0'> Seleccione la Cotizacion </option> ";
	
	while($rowCotizacion= sqlsrv_fetch_array($resultadoCotizacion, SQLSRV_FETCH_ASSOC)){
	
	$NumCotiza = $rowCotizacion['NROCOTIZ'];
	$NumCotiza1 = $rowCotizacion['NROCOTIZ'];
	
	$htmlCotizacion.= '<option value = "'.$NumCotiza.'" > '.$NumCotiza1.' </option>';
	
	}
	
	echo $htmlCotizacion;
		
?>