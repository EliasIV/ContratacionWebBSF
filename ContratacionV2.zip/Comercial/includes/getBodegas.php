<?php
	include("../../Conexion/conexion_sql_server_7.php");

	$CEN_CODIGO=$_POST['CEN_CODIGO'];

	#$CEN_CODIGO ="KCH";

	$agno = date("Y"); 
	$mes= date("m");
							
	$agno2 = substr(date("Y") , -2);

	$conc = $mes.$agno2;

	$MyQuerryBodegas = "select BODE_GRUPO, BODE_NROBODEGA, BODE_TBODEGA, BODE_TOTM2, BODE_VALM2, BODE_RENTAUF from BODE$conc where BODE_CENTRO = '$CEN_CODIGO' order by BODE_NROBODEGA";
	
	$resultadoBodegas = sqlsrv_query($con7, $MyQuerryBodegas);
	
	$htmlBodegas = "<option value='0'> Seleccione la Bodega </option> ";

	while($valoresBodegas = sqlsrv_fetch_array($resultadoBodegas, SQLSRV_FETCH_ASSOC)){
	
	$codigoBodegas = $valoresBodegas['BODE_NROBODEGA'];
	$nombreBodegas = $valoresBodegas['BODE_NROBODEGA'];


	#$html= '<option value = "'.$codigo3.'" > '.$nombre3.' </option>';
	
	$htmlBodegas.= "<option value = '".$valoresBodegas['BODE_NROBODEGA']."' > ".$valoresBodegas['BODE_NROBODEGA']." </option>";

	#echo $htmlBodegas;

	}
	
	echo $htmlBodegas;

	#echo $html;
?>