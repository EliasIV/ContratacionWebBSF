<?php

include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Cotizacion=$_POST['Cotizacion'];

	#$Cotizacion =8547;

	#$MyQuerryM2ByCotizacion = " select SUM( CONVERT (FLOAT , ROUND (det.M2 , 2, 1))) as TOTAL_M2
	#							from  MTIPBODE mt, DETCOTIZA det , MAECOTIZA mc
	#							where mt.COD_ITEM = det.CODIGO and det.NROCOTIZ = mc.NROCOTIZ and mc.RUT_EMPRESA = $RutEmpresa and (mt.COD_ITEM = 'BD001' or mt.COD_ITEM = 'BD002' or mt.COD_ITEM = 'BD003' or mt.COD_ITEM = 'BD004' 
	#							or mt.COD_ITEM = 'CD001' or mt.COD_ITEM = 'CD002' or mt.COD_ITEM = 'CD003' or mt.COD_ITEM = 'CD004' or mt.COD_ITEM = 'CD005'
	#							or mt.COD_ITEM = 'MB001' or mt.COD_ITEM = 'MB002' or mt.COD_ITEM = 'MB003' or mt.COD_ITEM = 'MB004' or mt.COD_ITEM = 'MB005' or mt.COD_ITEM = 'MB006' or mt.COD_ITEM = 'MB007' or
	#							mt.COD_ITEM = 'MB008' or mt.COD_ITEM = 'MB009' or mt.COD_ITEM = 'MB010') "; 


	$MyQuerryM2ByCotizacion = " select SUM( CONVERT (FLOAT , ROUND (det.M2 , 2, 1))) as TOTAL_M2
								from  MTIPBODE mt, DETCOTIZA det
								where mt.COD_ITEM = det.CODIGO and det.NROCOTIZ = $Cotizacion and (mt.COD_ITEM = 'BD001' or mt.COD_ITEM = 'BD002' or mt.COD_ITEM = 'BD003' or mt.COD_ITEM = 'BD004' 
								or mt.COD_ITEM = 'CD001' or mt.COD_ITEM = 'CD002' or mt.COD_ITEM = 'CD003' or mt.COD_ITEM = 'CD004' or mt.COD_ITEM = 'CD005'
								or mt.COD_ITEM = 'MB001' or mt.COD_ITEM = 'MB002' or mt.COD_ITEM = 'MB003' or mt.COD_ITEM = 'MB004' or mt.COD_ITEM = 'MB005' or mt.COD_ITEM = 'MB006' or mt.COD_ITEM = 'MB007' or
								mt.COD_ITEM = 'MB008' or mt.COD_ITEM = 'MB009' or mt.COD_ITEM = 'MB010') ";
	
	$resultadoM2ByCotizacion = sqlsrv_query($con7, $MyQuerryM2ByCotizacion);
	
	while($valoresM2ByCotizacion = sqlsrv_fetch_array($resultadoM2ByCotizacion, SQLSRV_FETCH_ASSOC)){
	
	$TotalM2 = $valoresM2ByCotizacion['TOTAL_M2'];
	
	$htmlM2ByCotizacion = $TotalM2;

	}
	
	echo $htmlM2ByCotizacion;




?>