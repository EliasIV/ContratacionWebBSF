<?php
	include("../../Conexion/conexion_sql_server.php");

	$id_region=$_POST['id_region'];

	#$id_region =7;

	$MyQuerryProvincia = " SELECT PROVINCIA_ID, PROVINCIA_NOMBRE FROM tbl_PROVINCIA WHERE (REGION_ID = $id_region) order by PROVINCIA_NOMBRE ";
	
	$resultadoProvincia = sqlsrv_query($con, $MyQuerryProvincia);
	
	$htmlProvincia = "<option value='0'> Seleccione la Provincia </option> ";

	while($valoresProvincia = sqlsrv_fetch_array($resultadoProvincia, SQLSRV_FETCH_ASSOC)){
	
	$codigoProvincia = $valoresProvincia['PROVINCIA_ID'];
	$nombreProvincia = $valoresProvincia['PROVINCIA_NOMBRE'];


	#$html= '<option value = "'.$codigo3.'" > '.$nombre3.' </option>';
	
	$htmlProvincia.= "<option value = '".$codigoProvincia."' > ".$nombreProvincia." </option>";

	#echo $htmlBodegas;

	}
	
	echo $htmlProvincia;

	#echo $html;
?>