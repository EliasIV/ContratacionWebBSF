<?php
	include("../../Conexion/conexion_sql_server_7.php");

	$Rut_Cliente=$_POST['Rut_Empresa'];

	#$Rut_Cliente ="96792430";

	$agno = date("Y"); 
	$mes= date("m");
							
	$agno2 = substr(date("Y") , -2);

	$conc = $mes.$agno2;
	
	#SUM( CONVERT (FLOAT , ROUND (det.M2 , 2, 1))) as TOTAL_M2
	
	#SELECT CASE WHEN SUM(BODE_TOTM2 ) is NOT NULL then SUM(BODE_TOTM2 ) else '0' end as M2_ARRENDADOS FROM BODE$conc WHERE (BODE_RUTCLTE = $Rut_Cliente)
	
	$MyQuerryM2Arrendados = " SELECT CASE WHEN SUM(( CONVERT (FLOAT , ROUND (BODE_TOTM2 , 2, 1))) ) is NOT NULL then SUM(( CONVERT (FLOAT , ROUND (BODE_TOTM2 , 2, 1))) ) else '0' end as M2_ARRENDADOS FROM BODE$conc WHERE (BODE_RUTCLTE = $Rut_Cliente) ";



	#$MyQuerryBodegas = "select BODE_GRUPO, BODE_NROBODEGA, BODE_TBODEGA, BODE_TOTM2, BODE_VALM2, BODE_RENTAUF from BODE$conc where BODE_CENTRO = '$CEN_CODIGO' order by BODE_NROBODEGA";
	
	$resultadoM2Arrendados = sqlsrv_query($con7, $MyQuerryM2Arrendados);
	
	#$htmlBodegas = "<option value='0'> Seleccione la Bodega </option> ";

	while($valoresM2Arrendados= sqlsrv_fetch_array($resultadoM2Arrendados, SQLSRV_FETCH_ASSOC)){
	
	$M2ARRENDADOS = $valoresM2Arrendados['M2_ARRENDADOS'];
	


	#$html= '<option value = "'.$codigo3.'" > '.$nombre3.' </option>';
	
	#$htmlBodegas.= "<option value = '".$valoresBodegas['BODE_NROBODEGA']."' > ".$valoresBodegas['BODE_NROBODEGA']." </option>";

	#echo $htmlBodegas;

	}
	
	echo $M2ARRENDADOS;

	#echo $html;
	
	?>