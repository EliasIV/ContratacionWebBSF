<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Cotizacion=$_POST['Cotizacion'];

	#$Cotizacion =8398;

	#$MyQuerryComuna = " SELECT DES_PTO_PGO FROM DETCOTIZA WHERE NROCOTIZ = 8398 ";
	$MyQuerryComuna = "SELECT distinct CONVERT (FLOAT, ROUND(DES_PTO_PGO , 2 ,1)) as DES_PTO_PGO FROM DETCOTIZA WHERE NROCOTIZ = $Cotizacion";
	$resultadoComuna = sqlsrv_query($con7, $MyQuerryComuna);
	
	#$htmlComuna = "<option value='0'> Seleccione la Comuna </option> ";

	while($valoresComuna = sqlsrv_fetch_array($resultadoComuna, SQLSRV_FETCH_ASSOC)){
	
	#$codigoComuna = $valoresComuna['COMUNA_ID'];
	#$nombreComuna = $valoresComuna['COMUNA_NOMBRE'];


	#$html= '<option value = "'.$codigo3.'" > '.$nombre3.' </option>';
	
	$htmlComuna = $valoresComuna['DES_PTO_PGO'];

	#echo $htmlBodegas;

	}
	
	echo $htmlComuna;

	#echo $html;
?>