<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Nro_Cotizacion=$_POST['Nro_Cotizacion'];
	
	$Rut_Empresa = $_POST['Rut_Empresa'];

	#$Nro_Cotizacion = 8726;
	
	#$Rut_Empresa = 78137000;
	
	$MyQuerryPlazoContrato = " select top 1 SUBSTRING( det.PLA_CONTRATO , 1, 2 ) as Plazo_Contrato from [dbo].[MAECOTIZA] mae, [dbo].[DETCOTIZA] det where det.NROCOTIZ = mae.NROCOTIZ and det.NROCOTIZ = $Nro_Cotizacion and mae.RUT_EMPRESA = $Rut_Empresa ";
	$resultadoPlazoContrato = sqlsrv_query($con7, $MyQuerryPlazoContrato);
	
	while($valoresPlazoContrato = sqlsrv_fetch_array($resultadoPlazoContrato, SQLSRV_FETCH_ASSOC)){
	
	$valor = $valoresPlazoContrato['Plazo_Contrato'];
	
	$htmlPlazoContrato = '<option value = "'.$valor.'" > '.$valor.' </option>';

	}
	
	echo $htmlPlazoContrato;

?>


