<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	$Rut_Empresa=$_POST['Rut_Empresa'];
	
	$Nro_Cotizacion=$_POST['Nro_Cotizacion'];

	#$Rut_Empresa = '96708670';
	
	#$Nro_Cotizacion = '8511';
	
	#$MyQuerryCotizacion_Correo = "SELECT top 1 EMAIL , ID FROM MAECOTIZA WHERE RUT_EMPRESA = '$Rut_Empresa' and ESTADO = 1";
	
	$MyQuerryCotizacion_Correo = "SELECT top 1 EMAIL , ID FROM MAECOTIZA WHERE RUT_EMPRESA = '$Rut_Empresa' and ESTADO = 1 and NROCOTIZ = $Nro_Cotizacion";
	
	$resultadoCotizacion_Correo = sqlsrv_query($con7, $MyQuerryCotizacion_Correo);
	
	#$htmlCotizacion_Correo = "<option value='0'> Seleccione el correo </option> ";
	
	while($rowCotizacion_Correo = sqlsrv_fetch_array($resultadoCotizacion_Correo, SQLSRV_FETCH_ASSOC)){
	
	$Id_Correo_Cotiza = $rowCotizacion_Correo['ID'];
	$Correo_Contacto_Cotiza = $rowCotizacion_Correo['EMAIL'];
	
	$htmlCotizacion_Correo = '<option value = "'.$Id_Correo_Cotiza.'" > '.$Correo_Contacto_Cotiza.' </option>';
	
	}
	
	echo $htmlCotizacion_Correo;
		
?>