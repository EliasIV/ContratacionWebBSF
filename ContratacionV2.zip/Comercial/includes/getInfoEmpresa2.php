<?php
	include("../../Conexion/conexion_sql_server_7_Cotizacion.php");

	#$valor1 = $_POST['valorCaja1']; 
	#$valor2=$_POST['valorCaja2']; 

	$valor1 = 69220100;
	
	$valor2 = 0;
							
	$MyQuerry3 = " SELECT NROCOTIZ, EMPRESA FROM MAECOTIZA Where RUT_EMPRESA = '$valor1' and DV_EMPRESA = '$valor2' ORDER BY ID DESC ";
	
	$resultado3 = sqlsrv_query($con7,$MyQuerry3);
	
	while($valores3= sqlsrv_fetch_array($resultado3, SQLSRV_FETCH_ASSOC)){
	
	$NumCotiza = $valores3['NROCOTIZ'];
	$NombreEmpresa = $valores3['EMPRESA'];
	}

	echo $NumCotiza;
	echo "-";
	echo $NombreEmpresa;
	
?>