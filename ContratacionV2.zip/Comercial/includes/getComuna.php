<?php
	include("../../Conexion/conexion_sql_server.php");

	$id_provincia=$_POST['id_provincia'];

	#$id_provincia =7;

	$MyQuerryComuna = " SELECT COMUNA_ID, COMUNA_NOMBRE FROM tbl_COMUNAS WHERE (PROVINCIA_ID = $id_provincia) ";
	
	$resultadoComuna = sqlsrv_query($con, $MyQuerryComuna);
	
	$htmlComuna = "<option value='0'> Seleccione la Comuna </option> ";

	while($valoresComuna = sqlsrv_fetch_array($resultadoComuna, SQLSRV_FETCH_ASSOC)){
	
	$codigoComuna = $valoresComuna['COMUNA_ID'];
	$nombreComuna = $valoresComuna['COMUNA_NOMBRE'];


	#$html= '<option value = "'.$codigo3.'" > '.$nombre3.' </option>';
	
	$htmlComuna.= "<option value = '".$codigoComuna."' > ".$nombreComuna." </option>";

	#echo $htmlBodegas;

	}
	
	echo $htmlComuna;

	#echo $html;
?>