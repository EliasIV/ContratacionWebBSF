<?php
date_default_timezone_set("America/Santiago");
session_start();
include("../Conexion/conexion_sql_server.php");
#include("../Conexion/conexion_sql_server_7.php");

?>

<!doctype html>
<html lang="en">
  <head>
  
		<!-- Estilos en CSS -->
	<style>
		.borde{border: 1px #000 solid; text-align:center; heigth: 50px;}
		.color1{background: #eeeeee;}
		.color2{background: #f6f6f6;}
		.color3{background: #94ac3c;}
		.color4{background: #295ba7;}
	
	</style>


	<title> Area del Cliente</title>
    <!-- Required meta tags -->
    <link rel="shortcut icon" href="../images/favicon.ico"/>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">


<!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Bootstrap4 Duallistbox -->
  <link rel="stylesheet" href="plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
	

	<script language="javascript" src="../js/jquery-3.4.1.min.js"> </script>
	
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
	
	
	<!-- Bootstrap css library -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Bootstrap js library -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
		
	<script src="js/validadorRut.js"></script>
	
	<script src="validarRutContable/validadorRutContable.js"></script>


	<!-- CODIGO JQUERY -->
<script language = "javascript">
			$(document).ready(function () {
				$("#cmbx_Centro_Logistico").change(function () {

				$("#cmbx_Centro_Logistico option:selected" ).each(function (){
					CEN_CODIGO = $(this).val();
		
					$.post("includes/getBodegas.php", { CEN_CODIGO: CEN_CODIGO
					}, function(data){
						$("#cmbx_Bodega").html(data);
});
});
});
});

			$(document).ready(function () {
				$("#cmbx_Bodega").change(function () {

				$("#cmbx_Bodega option:selected").each(function (){
					
					//var BODE_CENTRO = $('#cmbx_Centro_Logistico').html(data);
					
					BODE_NROBODEGA = $(this).val();
					

					$.post("includes/getM2.php", { BODE_NROBODEGA: BODE_NROBODEGA //, BODE_CENTRO: BODE_CENTRO
					}, function(data){
						$("#cmbx_M2").html(data);
					});
				});
			});
		});

</script>


<script>
function realizaProceso(RutEmpresa, DV){
        var parametros = {
                "RutEmpresa" : RutEmpresa,
                "DV" : DV
        };
        $.ajax({
                data:  parametros,
                url:   'includes/getInfoEmpresa.php',
                type:  'post',
                beforeSend: function () {
                        $("#resultado").html("Procesando, espere por favor...");
                },
                success:  function (response) {
						var splitted = response.split("-"); // RESULT
						$("#Cotizacion").val(splitted[0]);
						$("#NombreEmpresa").val(splitted[1]);
                }
        });
}
</script>
	


<script>
	$(function(){
		$("#adicional").on('click', function(){
			$("#tabla tbody tr:eq(0)").clone().removeClass('fija-fija').appendTo("#tabla");
		});		
		
		$(document).on("click",".eliminar" , function(){
			var parent = $(this).parents().get(0);
			$(parent).remove();
		});
	});



</script>


<script>
	$('.agregar_producto').on('click', function(){
	var clone = $( ".contenido:first" ).clone();
	$(clone).attr('id','changedId'); //change cloned element id attribute
	$(clone).find('select').attr('id','changedId1'); //change cloned element children attribute also
	$(clone).insertAfter( ".contenido:last" );
	});
	
	#changedId{
	 background:yellow;
	}

	#changedId1{
	 font-size:20px;
	 color:red;
	}

</script>



<!-- DIV DE PERSONERIA JURIDICA -->
<script>
$(document).ready(function(){
    //group add limit
    var maxGroup = 10;
    
    //add more fields group
    $(".addMore").click(function(){
        if($('body').find('.fieldGroup').length < maxGroup){
            var fieldHTML = '<div class="form-group fieldGroup">'+$(".fieldGroupCopy").html()+'</div>';
            $('body').find('.fieldGroup:last').after(fieldHTML);
        }else{
            alert('Maximum '+maxGroup+' groups are allowed.');
        }
    });
    
    //remove fields group
    $("body").on("click",".remove",function(){ 
        $(this).parents(".fieldGroup").remove();
    });
});

</script>
<!-- FIN -->



<!-- DIV DE REPRESENTANTE LEGAL -->
<script>
$(document).ready(function(){
    //group add limit
    var maxGroup = 10;
    
    //add more fields group
    $(".addMore2").click(function(){
        if($('body').find('.fieldGroup2').length < maxGroup){
            var fieldHTML = '<div class="form-group2 fieldGroup2">'+$(".fieldGroupCopy2").html()+'</div>';
            $('body').find('.fieldGroup2:last').after(fieldHTML);
        }else{
            alert('Maximum '+maxGroup+' groups are allowed.');
        }
    });
    
    //remove fields group
    $("body").on("click",".remove",function(){ 
        $(this).parents(".fieldGroup2").remove();
    });
});

</script>
<!-- FIN -->


<!-- SCRIPT PARA COPIAR EN LOS INPUT DE AREA CONTABLE -->

<script>

function copyTextValueContable(bf) {
  var Nombre_Legal = bf.checked ? document.getElementById("Nombre_Legal").value : '';
  var Apellido_Legal = bf.checked ? document.getElementById("Apellido_Legal").value : '';
  var Rut_Legal = bf.checked ? document.getElementById("Rut_Legal").value : '';
  var Email_Legal = bf.checked ? document.getElementById("Email_Legal").value : '';
  var Telefono_Legal = bf.checked ? document.getElementById("Telefono_Legal").value : '';
  
  document.getElementById("Nombre_Contable").value = Nombre_Legal;
  document.getElementById("Apellido_Contable").value = Apellido_Legal;
  document.getElementById("Rut_Contable").value = Rut_Legal;
  document.getElementById("Correo_Contable").value = Email_Legal;
  document.getElementById("Telefono_Movil_Contable").value = Telefono_Legal;
}

</script>


<!-- FIN -->


<!-- SCRIPT PARA COPIAR EN LOS INPUTS DE AREA DE COMERCIAL -->

<script>

function copyTextValueComercial (bf) {
  var Nombre_Legal = bf.checked ? document.getElementById("Nombre_Legal").value : '';
  var Apellido_Legal = bf.checked ? document.getElementById("Apellido_Legal").value : '';
  var Rut_Legal = bf.checked ? document.getElementById("Rut_Legal").value : '';
  var Email_Legal = bf.checked ? document.getElementById("Email_Legal").value : '';
  var Telefono_Legal = bf.checked ? document.getElementById("Telefono_Legal").value : '';
  
  document.getElementById("Nombre_Comercial").value = Nombre_Legal;
  document.getElementById("Apellido_Comercial").value = Apellido_Legal;
  document.getElementById("Rut_Comercial").value = Rut_Legal;
  document.getElementById("Correo_Comercial").value = Email_Legal;
  document.getElementById("Telefono_Movil_Comercial").value = Telefono_Legal;
}

</script>

<!-- FIN -->

<!-- SCRIPT PARA COPIAR EN LOS INPUTS DE CONTACTO DE BODEGA -->

<script>

function copyTextValueContactoBodega (bf) {
  var Nombre_Legal = bf.checked ? document.getElementById("Nombre_Legal").value : '';
  var Apellido_Legal = bf.checked ? document.getElementById("Apellido_Legal").value : '';
  var Rut_Legal = bf.checked ? document.getElementById("Rut_Legal").value : '';
  var Email_Legal = bf.checked ? document.getElementById("Email_Legal").value : '';
  var Telefono_Legal = bf.checked ? document.getElementById("Telefono_Legal").value : '';
  
  document.getElementById("Nombre_Bodega").value = Nombre_Legal;
  document.getElementById("Apellido_Bodega").value = Apellido_Legal;
  document.getElementById("Rut_Bodegas").value = Rut_Legal;
  document.getElementById("Correo_Electronico_Bodega").value = Email_Legal;
  document.getElementById("Telefono_Bodega").value = Telefono_Legal;
}

</script>







<!-- SCRIPT PARA COPIAR LOS DATOS EN LOS INPUTS DE AREA CONTABLE Y COMERCIAL -->

<script>

function copyTextValueContable_Comercial (bf) {
  var Nombre_Legal = bf.checked ? document.getElementById("Nombre_Legal").value : '';
  var Apellido_Legal = bf.checked ? document.getElementById("Apellido_Legal").value : '';
  var Rut_Legal = bf.checked ? document.getElementById("Rut_Legal").value : '';
  var Email_Legal = bf.checked ? document.getElementById("Email_Legal").value : '';
  var Telefono_Legal = bf.checked ? document.getElementById("Telefono_Legal").value : '';
  
  
  document.getElementById("Nombre_Contable").value = Nombre_Legal;
  document.getElementById("Apellido_Contable").value = Apellido_Legal;
  document.getElementById("Rut_Contable").value = Rut_Legal;
  document.getElementById("Correo_Contable").value = Email_Legal;
  document.getElementById("Telefono_Movil_Contable").value = Telefono_Legal;
  
  
  document.getElementById("Nombre_Comercial").value = Nombre_Legal;
  document.getElementById("Apellido_Comercial").value = Apellido_Legal;
  document.getElementById("Rut_Comercial").value = Rut_Legal;
  document.getElementById("Correo_Comercial").value = Email_Legal;
  document.getElementById("Telefono_Movil_Comercial").value = Telefono_Legal;


  document.getElementById("Nombre_Bodega").value = Nombre_Legal;
  document.getElementById("Apellido_Bodega").value = Apellido_Legal;
  document.getElementById("Rut_Bodegas").value = Rut_Legal;
  document.getElementById("Correo_Electronico_Bodega").value = Email_Legal;
  document.getElementById("Telefono_Bodega").value = Telefono_Legal;
  
}

</script>

<!-- FIN -->

<!-- SCRIPT PARA OBTENER LA PROVINCIA -->
<script language="javascript">
$(document).ready(function(){
	$("#cmbx_Region").change(function(){
		
		$("#cmbx_Region option:selected").each(function(){
			id_region = $(this).val();
			$.post("includes/getProvincia.php", { id_region: id_region
			}, function(data){
				$("#cmbx_Provincia").html(data);
			});
		});
		
	})
});





$(document).ready(function(){
	$("#cmbx_Provincia").change(function(){
		
		$("#cmbx_Provincia option:selected").each(function(){
			id_provincia = $(this).val();
			$.post("includes/getComuna.php", { id_provincia: id_provincia
			}, function(data){
				$("#cmbx_Comuna").html(data);
			});
		});
		
	})
});


</script>
<!-- FIN -->



<!-- SCRIPT PARA OBTENER LA COMUNA -->
<script>

</script>
<!-- FIN -->

<!-- SCRIPT PARA VALIDAR EL RUT CHILENO -->
<script>

document.getElementById('rut').addEventListener('input', function(evt) {
  let value = this.value.replace(/\./g, '').replace('-', '');
  
  if (value.match(/^(\d{2})(\d{3}){2}(\w{1})$/)) {
    value = value.replace(/^(\d{2})(\d{3})(\d{3})(\w{1})$/, '$1.$2.$3-$4');
  }
  else if (value.match(/^(\d)(\d{3}){2}(\w{0,1})$/)) {
    value = value.replace(/^(\d)(\d{3})(\d{3})(\w{0,1})$/, '$1.$2.$3-$4');
  }
  else if (value.match(/^(\d)(\d{3})(\d{0,2})$/)) {
    value = value.replace(/^(\d)(\d{3})(\d{0,2})$/, '$1.$2.$3');
  }
  else if (value.match(/^(\d)(\d{0,2})$/)) {
    value = value.replace(/^(\d)(\d{0,2})$/, '$1.$2');
  }
  this.value = value;
});

</script>
	
<!-- FIN -->



<!-- SCRIPT PARA CALCULAR EL TAMAÑO DEL ARCHIVO -->

<script>
//Funcion de JS que valida el archivo ingresado al input. Formato y Tamaño.
function validarFile(all)
{
    //EXTENSIONES Y TAMANO PERMITIDO.
    var extensiones_permitidas = [".pdf"];
    var tamano = 3; // EXPRESADO EN MB.
    var rutayarchivo = all.value;
    var ultimo_punto = all.value.lastIndexOf(".");
    var extension = rutayarchivo.slice(ultimo_punto, rutayarchivo.length);
    if(extensiones_permitidas.indexOf(extension) == -1)
    {
        alert("Extensión de archivo no valida");
        document.getElementById(all.id).value = "";
        return; // Si la extension es no válida ya no chequeo lo de abajo.
    }
    if((all.files[0].size / 1048576) > tamano)
    {
        alert("El archivo no puede superar los "+tamano+"MB");
        document.getElementById(all.id).value = "";
        return;
    }
}
</script>

<!-- FIN -->


<!-- SCRIPT PARA DESABILITAR MODULO DE REPRESENTANTE LEGAL Y PERSONERIA JURIDICA -->
<script>
		   function comprobar(obj)
{   
    if (obj.checked){
      document.getElementById('Nombre_Legal').readOnly = true;
	  document.getElementById('Apellido_Legal').readOnly = true;
	  document.getElementById('Nacionalidad_Legal').readOnly = true;
	  document.getElementById('EstadoCivil_Legal').readOnly = true;
	  document.getElementById('Telefono_Legal').readOnly = true;
	  document.getElementById('Profesion_Legal').readOnly = true;
	  document.getElementById('Rut_Legal').readOnly = true;
	  document.getElementById('Email_Legal').readOnly = true;
	  document.getElementById('Nombre_Notario_Legal').readOnly = true;
	  document.getElementById('Fecha_Constitucion_Legal').readOnly = true;
	  document.getElementById('check1').disabled = true;
	  document.getElementById('check2').disabled = true;
	  document.getElementById('check3').disabled = true;
	  document.getElementById('text1').disabled = true;
	  
	  document.getElementById('AgregarRepresentanteLegal').hidden = true;
	  
        
	}
    else {
      document.getElementById('Nombre_Legal').readOnly = false;
	  document.getElementById('Apellido_Legal').readOnly = false;
	  document.getElementById('Nacionalidad_Legal').readOnly = false;
	  document.getElementById('EstadoCivil_Legal').readOnly = false;
	  document.getElementById('Telefono_Legal').readOnly = false;
	  document.getElementById('Profesion_Legal').readOnly = false;
	  document.getElementById('Rut_Legal').readOnly = false;
	  document.getElementById('Email_Legal').readOnly = false;
	  document.getElementById('Nombre_Notario_Legal').readOnly = false;
	  document.getElementById('Fecha_Constitucion_Legal').readOnly = false;
	  document.getElementById('check1').disabled = false;
	  document.getElementById('check2').disabled = false;
	  document.getElementById('check3').disabled = false;
	  document.getElementById('text1').disabled = false;
	  
	  document.getElementById('AgregarRepresentanteLegal').hidden = false;
	  
	  
	  
	}
}
</script>
<!-- FIN -->



	<!-- FIN --> 
  </head>
  <body>
	<div class="container">
		<div class="row"> 
			<div class="borde color4 col-sm-12">HEADER </div>
		
		</div>
		<div class="row"> 
	<div class="borde color2 col-sm-12 col-md-12">Registro de Contrato Comercial  
			
				<!-- CONTENIDO -->
			
					<section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
           <div class="col-md-12">
            <!-- general form elements disabled -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Informacion de Empresa</h3>
              </div>
              <!-- /.card-header -->
			<form id="RegistroComercialCliente" name="RegistroComercialCliente" action="RegistroRevisionWeb" method="POST">
              <div class="card-body">
			  
			   <div class="row">
			   
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Numero Resumen Contrato</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Numero de Contrato" disabled>
                  </div>
				</div>
			   
			   
				<div class="col-sm-6">
                      <div class="form-check">
                          <input class="only-one" type="checkbox" disabled> 
                          <label class="exampleInputEmail1">Contrado Nuevo</label>  
                        </div>
						
						
						 
                      <div class="form-check">
                          <input class="only-one" type="checkbox" onchange="habilitar(this.checked);" disabled> 
                           <label class="exampleInputEmail1">Anexo de Contrato </label> 
                        </div>
                    
						
                </div>
			   
			   
			   </div>
			   
			   
			    <div class="row">
                    <div class="col-sm-6">
                      <!-- textarea -->
                      <div class="form-group">
                        <label>Numero de Contrato</label>
                        <input type="text" class="form-control" placeholder="Anexo Contrato"  id="AnexoContrato" disabled >
                      </div>				  
					  
                    </div>
					
					
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Anexo Contrato</label>
                        <input type="text" class="form-control" placeholder="Numero de Contrato" id="NumeroContrato" disabled >
                      </div>
                    </div>
                  </div>
			  
                  <div class="row">			
					
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>R.U.T. Empresa</label>                      
						<select id="cmbx_Rut_Empresa" name="cmbx_Rut_Empresa" class="form-control select2" style="width: 100%;" disabled>
						<option value="0"> Seleccione Rut del Cliente </option>
						
						<!-- CODGIDO PHP -->
						<?php
														
							$serverName="BSFRESPALDO\BDBSF2";
							$connectionInfo = array("Database"=> "BSFContratacionWeb", "UID"=>"sa", "PWD"=>"golfo9710", "CharacterSet"=>"UTF-8");
							$con = sqlsrv_connect($serverName, $connectionInfo);
							
							$MyQuerryRegion = "SELECT REGION_ID, REGION_NOMBRE FROM tbl_REGIONES order by REGION_ID";
							$resultadoRegion = sqlsrv_query($con, $MyQuerryRegion);

							while($valores_Region= sqlsrv_fetch_array($resultadoRegion, SQLSRV_FETCH_ASSOC)){
							$Region_ID = $valores_Region['REGION_ID'] ;
							$Region_Nombre = $valores_Region['REGION_NOMBRE'] ;
							
							echo '<option value = "'.$Region_ID.'" > '.$Region_Nombre.' </option>';
							}
							
							sqlsrv_close();
						?>
						
						</select>
						<p id ="resultado11">
                      </div>
                    </div>					
					
					<div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Nombre de Empresa</label>
                        <!-- <input type="text" class="form-control"  id="NombreEmpresa" placeholder="Nombre Empresa" disabled> -->
						<select class="form-control select2" id="cmbx_Nombre_Empresa" name="cmbx_Nombre_Empresa" disabled> 
							<option value="0"> Seleccione la empresa </option>
						</select>				
                      </div>  
                    </div>
					
					
                  </div>
				  
				  
				  
				  <div class="row">	
					<div class="col-sm-6">
						<div class="form-group">
							<label>Número de Cotizacion</label>						
							<select id="cmbx_Cotizacion_Activa" name="cmbx_Cotizacion_Activa" class="form-control select2" disabled>
							<option value="0"> Seleccione la Cotizacion </option> 
						</select>
                      </div>
				   </div>
				   
				   <div class="col-sm-6">
						<div class="form-group">
							<label>Nombre de Contacto</label>						
							<select id="cmbx_Nombre_Contacto" name="cmbx_Nombre_Contacto" class="form-control select2" disabled >
							<option value="0"> Seleccione el contacto </option> 
						</select>
                      </div>
				   </div>
				  
				  
				  </div>
				  
				  
				  
				  
				   <div class="row">	
					<div class="col-sm-6">
						<div class="form-group">
							<label>Correo de Contacto</label>						
							<select id="cmbx_Correo_Contacto" name="cmbx_Correo_Contacto" class="form-control select2" disabled >
							<option value="0"> Seleccione el correo </option> 
						</select>
                      </div>
				   </div>
				   
				   <div class="col-sm-3">
						<div class="form-group">
							<label>Telefono de Contacto</label>						
								<select id="cmbx_Telefono_Contacto" name="cmbx_Telefono_Contacto" class="form-control select2" disabled >
									<option value="0"> Seleccione el telefono </option> 
								</select>
						</div>
					</div>
					  
					  <div class="col-sm-3">
						<div class="form-group">
							<label>Telefono de Fax</label>						
								<select id="cmbx_Fax_Contacto" name="cmbx_Fax_Contacto" class="form-control select2" disabled>
									<option value="0"> Seleccione el fax </option> 
								</select>
						</div>
					  </div>
				  </div>	  	  
                 
                  <!-- input states -->    
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            <!-- general form elements disabled -->
            
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
	  
	    <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Informacion Bodega</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             
                <div class="card-body">
				<div class="row">
				<div class="col-sm-6">

				<div class="form-group">
                  <label>Centro Logistico</label>
                  <select id="cmbx_Centro_Logistico" name="cmbx_Centro_Logistico" class="form-control select2" style="width: 100%;" disabled>
						<option value="0"> Seleccione Centro Logistico </option>

						<!-- CODGIDO PHP -->
						<?php
								
							
							$MyQuerry = "select CEN_CODIGO, CEN_NOMBRE FROM tbl_CENTRO";
							$resultado = sqlsrv_query($con, $MyQuerry);

							while($valores= sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)){
							$codigo = $valores['CEN_CODIGO'];
							$nombre = $valores['CEN_NOMBRE'];

							echo '<option value = "'.$valores['CEN_CODIGO'].'" > '.$valores['CEN_NOMBRE'].' </option>';

							}
							#sqlsrv_close($con7);
						?>
						<!-- FIN -->
                  </select>
                </div>
				</div>
				  <div class="col-sm-6">
                      <div class="form-check">
							<label class="form-check-label">Fecha Inicio</label>
							
							<input type="date" id="MyDate" class="form-control"   value="fechaing" disabled>
                        </div>
                    </div>
				  </div>
				  <div class="row">
				 <div class="col-sm-6">
					<div class="form-group"> 
						<label> Selecciona la Bodega: </label>
						<select class="form-control select2" onchange="miFuncion()" id="cmbx_Bodega" name="cmbx_Bodega" style="width: 100%;" disabled>
							<option value="0"> Seleccione la Bodega </option>
						</select>
					</div>
				 </div>
				  	  
				  <div class="col-sm-6">
                      <div class="form-check">
                          <label class="form-check-label">Numero de Meses </label>
						   <input type="email" class="form-control" id="MyDate2"" placeholder="999"onkeypress="return solonumeros(event)" maxlength="3" onChange="AddMes()" disabled>
                        </div>
                    </div>
				  </div>    
				 
				 <div class="row">
				  <div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Numero(s) de Bodega(s)</label> <br>
					<label id= "mostrar"> </label><br>
					<label id="tutorial"></label>
                  </div>
				  </div>
				  	  
				  <div class="col-sm-6">
                      <div class="form-check">
                          <label class="form-check-label">Fecha Termino </label>
						  
						  <input  id="MyDate3" class="form-control" placeholder="Resultado final" disabled >
                        </div>
                    </div>
				  </div>
				 <div class="row"> 
				  <div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Superfice M2</label>
					<select class="form-control select2" id="cmbx_M2" name="cmbx_M2" onchange="miFuncion1()" onkeyup="busqueda();" disabled>
					</select>
					<label id="sumaM2"> </label>
                  </div>
				  </div>
				  <div class="col-sm-6">
                      <div class="form-check">
                          <label class="form-check-label">Meses Renovación </label>
						  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="9"onkeypress="return solonumeros(event)" maxlength="1" disabled>
                        </div>
                    </div>				  
				  </div>
				 
				  <div class="row"> 
				  <div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Descuento PP</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="99,99%" onkeypress="return filterFloat(event,this)" maxlength="7" disabled>
                  </div>
				  </div>
				  	  
				  <div class="col-sm-6">
					<div class="form-group">
                  <label>Dias Plazo Aviso</label>
                  <select class="form-control select2" style="width: 100%;" disabled>
						
						<!-- CODGIDO PHP -->
						<?php
							$MyQuerry1 = "SELECT * FROM tbl_PLAZO_AVISO";
							$resultado1 = sqlsrv_query($con, $MyQuerry1);

							while($valores1= sqlsrv_fetch_array($resultado1, SQLSRV_FETCH_ASSOC)){
							$codigo1 = $valores1['COD_PLAZO'];
							$nombre1 = $valores1['NOMBRE_PLAZO'];

							echo '<option value = "'.$codigo1.'" > '.$nombre1.' </option>';

							}
						?>
						<!-- FIN -->
                  </select>
                </div>
                    </div>
				  </div>			 
				 <div class="row">
				  <div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Renta Mensual (UF)</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="9999" onkeypress="return solonumeros(event)" maxlength="4" disabled>
                  </div>
				  </div>				  	  
				  <div class="col-sm-6">
                      <div class="form-check">
                          <label class="form-check-label">Monto Garantia (UF) </label>
						  <input type="email" class="form-control" id="exampleInputEmail1" placeholder="9999" onkeypress="return solonumeros(event)" maxlength="4" disabled>
                        </div>
                    </div>  
				  </div>
                </div>		   
            </div>
          </div>
		  
		  
		  <!-- MODULO DE DATOS EMPRESA -->
		  
		  <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Datos Empresa</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             
                <div class="card-body">
				<div class="row">
				
				<div class="col-sm-12">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Giro Empresa</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
                  </div>
				</div>
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Persona Natural</label>
                    <input class="only-one" type="checkbox" onchange="comprobar(this);""> 
                  </div>
				</div>
				
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Direccion - Calle</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
                  </div>
				</div>
				  
				  
				  
				  <div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Direccion - Número</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
                  </div>
				</div>
				  
				
				<div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Direccion - Oficina Número</label>
						<input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				<div class="col-sm-6">
					<div class="form-group">
					  <label>Direccion - Region</label>
					  <select id="cmbx_Region" name="cmbx_Region" class="form-control select2" style="width: 100%;" >
							<option value="0"> Seleccione la region </option>

							<!-- CODGIDO PHP -->
							<?php
														
							$serverName="BSFRESPALDO\BDBSF2";
							$connectionInfo = array("Database"=> "BSFContratacionWeb", "UID"=>"sa", "PWD"=>"golfo9710", "CharacterSet"=>"UTF-8");
							$con = sqlsrv_connect($serverName, $connectionInfo);
							
							$MyQuerryRegion = "SELECT REGION_ID, REGION_NOMBRE FROM tbl_REGIONES order by REGION_ID";
							$resultadoRegion = sqlsrv_query($con, $MyQuerryRegion);

							while($valores_Region= sqlsrv_fetch_array($resultadoRegion, SQLSRV_FETCH_ASSOC)){
							$Region_ID = $valores_Region['REGION_ID'] ;
							$Region_Nombre = $valores_Region['REGION_NOMBRE'] ;
							
							echo '<option value = "'.$Region_ID.'" > '.$Region_Nombre.' </option>';
							}
							
							sqlsrv_close();
						?>
							<!-- FIN -->
					  </select>
						</div>
					</div>
					
					
					<div class="col-sm-6">
					<div class="form-group"> 
						<label> Direccion - Provincia: </label>
						<select class="form-control select2" onchange="miFuncion()" id="cmbx_Provincia" name="cmbx_Provincia" style="width: 100%;" >
							<option value="0"> Seleccione la provincia </option>
						</select>
					</div>
				 </div>




					</div>				  
				  </div>
				  <div class="row">
				 
				  	  
				  <div class="col-sm-6">
                     
					<div class="form-group"> 
						<label> Direccion - Comuna: </label>
						<select class="form-control select2" onchange="miFuncion()" id="cmbx_Comuna" name="cmbx_Comuna" style="width: 100%;" >
							<option value="0"> Seleccione la comuna </option>
						</select>
					</div>
				 
                    </div>
				  </div>    
				 	 
                </div>		   
            </div>
			
			<!-- FIN -->
			
			
			<!-- MODULO DE REPRESENTANTE LEGAL -->
			
		<div class="form-group2 fieldGroup2">
			<div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Representante Legal</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             
                <div class="card-body">
				<div class="row">
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nombre</label>
                    <input type="email" class="form-control" id="Nombre_Legal" name = "Nombre_Legal" placeholder=" . . . "   >
                  </div>
				</div>
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Apellido</label>
                    <input type="email" class="form-control" id="Apellido_Legal" name="Apellido_Legal" placeholder=" . . . "   >
                  </div>
				</div>
				  
				  
				  
				  <div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nacionalidad</label>
                    <input type="email" class="form-control" id="Nacionalidad_Legal" name ="Nacionalidad_Legal" placeholder=" . . . "   >
                  </div>
				</div>
				  
				
				<div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Estado Civil</label>
						<input type="email" class="form-control" id="EstadoCivil_Legal" name="EstadoCivil_Legal" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				  <div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Telefono</label>
						<input type="email" class="form-control" id="Telefono_Legal" name="Telefono_Legal" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				  
				   <div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Profesion</label>
						<input type="email" class="form-control" id="Profesion_Legal" name="Profesion_Legal" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				
				</div>				  
				  </div>
				  
				  
				  <div class="row">
				
				  	  
				  <div class="col-sm-6">
                     
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">R.U.T</label>
						<!-- <input type="email" class="form-control" id="Rut_Legal" name="Rut_Legal" placeholder=" . . . "   > -->
						<input type="text" class="form-control" id="Rut_Legal" required placeholder="Ingrese su rut" name="Rut_Legal"onblur="return Rut(RegistroComercialCliente.Rut_Legal.value)"/>
					  </div>
					  
					  
					  
					</div>
				 
                    </div>
					
					<div class="col-sm-6">
                     
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Correo Electronico</label>
						<input type="email" class="form-control" id="Email_Legal" name="Email_Legal" placeholder=" . . . "   >
					  </div>
					</div>
				 
                    </div>
					
					
					
				  </div>  
				  
				  
				<div class="row">
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nombre notario firma acta</label>
                    <input type="text" class="form-control" id="Nombre_Notario_Legal" name ="Nombre_Notario_Legal" placeholder=" . . . "   >
                  </div>
				</div>
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Fecha de constitucion de empresa</label>
                    <input type="date" class="form-control" id="Fecha_Constitucion_Legal" name = "Fecha_Constitucion_Legal">
                  </div>
				</div>
				</div>	
				  
				  
				  
				  <div class="row">
					<div class="col-sm-3">
					   <div class="col-sm-12">
							<input type="checkbox" name="check1" id="check1" onchange="copyTextValueContable(this);"> Copiar - Contacto Contable </input>
						</div>
					</div>
					
					<div class="col-sm-3">
					   <div class="col-sm-12">
							<input type="checkbox" name="check2" id="check2" onchange="copyTextValueComercial(this);" > Copiar - Contacto Comercial </input>
						</div>
					</div>
					
					<div class="col-sm-3">
					   <div class="col-sm-12">
							<input type="checkbox" name="check3" id="check3" onchange="copyTextValueContactoBodega(this);" > Copiar - Encargado Bodega </input>
						</div>
					</div>
					
					<div class="col-sm-3">
					   <div class="col-sm-12">
							<input type="checkbox" name="check3" id="check3" onchange="copyTextValueContable_Comercial(this);" > Copiar - Contacto Comercial - Contacto Contable </input>
						</div>
					</div>
					
					
				  </div>
				  
				  
				  <div class="input-group-addon"> 
						<a href="javascript:void(0)" class="btn btn-success addMore2" id="AgregarRepresentanteLegal" name="AgregarRepresentanteLegal"><span class="glyphicon glyphicon glyphicon-plus" aria-hidden="true"></span> </a>
				  </div>	
				
				</div>	
            </div>
			</div>
			<!-- FIN -->
			
			
			
			<!-- MODULO DE PERSONERIA JURIDICA -->
			
		<div class="form-group fieldGroup">
			<div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Personería Jurídica</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             
             <div class="card-body">
				<div class="row">
				
				<div class="col-sm-10">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Documento a Adjuntar</label> <br>
					
					<span for="exampleInputFile">Archivo NO mayor a 3 MB / Solo Archivo Extensión .PDF</span>
					
                    <input type="file" name="text1" id="text1" accept="application/pdf" class="form-control" onchange="validarFile(this);">
									
                  </div>
				</div>			
				
				</div>				  
			</div>
				  
				</div>	
            </div>
			</div>
			
			
			<!-- MODULO DE CONTACTO CONTABLE - ENCARGADO DE PAGOS -->
			
		
			<div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Contacto Contable - Encargado de Pagos</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             
                <div class="card-body">
				<div class="row">
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nombre</label>
                    <input type="text" class="form-control" id="Nombre_Contable" name="Nombre_Contable" placeholder=" . . . "   >
                  </div>
				</div>
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Apellido</label>
                    <input type="email" class="form-control" id="Apellido_Contable" name="Apellido_Contable" placeholder=" . . . "   >
                  </div>
				</div>
				  
				  
				  
				  <div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Telefono Contacto</label>
                    <input type="email" class="form-control" id="Telefono_Contable" name="Telefono_Contable" placeholder=" . . . "   >
                  </div>
				</div>
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Telefono Movil</label>
                    <input type="email" class="form-control" id="Telefono_Movil_Contable" name="Telefono_Movil_Contable" placeholder=" . . . "   >
                  </div>
				</div>
				  
				
				<div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Correo Electrónico</label>
						<input type="email" class="form-control" id="Correo_Contable" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				  
				  <div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Direccion de envió Factura</label>
						<input type="email" class="form-control" id="Direccion_Factura_Contable" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				
				</div>				  
				  </div>
				  <div class="row">
				 <div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Cargo en la Empresa</label>
						<input type="email" class="form-control" id="Cargo_Empresa_Contable" name="Cargo_Empresa_Contable" placeholder=" . . . "   >
					  </div>
					</div>
				  </div>		 
				  <div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">RUT</label>
						<!-- <input type="email" class="form-control" id="Rut_Contable" name="Rut_Contable" placeholder=" . . . "   > -->
						<input type="text" class="form-control" id="Rut_Contable" required placeholder="Ingrese el Contable" name="Rut_Contable" onblur="return Rut2(RegistroComercialCliente.Rut_Contable.value)"/>
					  </div>
					</div>
				  </div>
				 
				  </div>  
					
				</div>	
            </div>
			
			<!-- FIN -->
			
			
			
			
			<!-- MODULO DE CONTACTO COMERCIAL -->
			
		
			<div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Contacto Comercial</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             
                <div class="card-body">
				<div class="row">
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nombre</label>
                    <input type="email" class="form-control" id="Nombre_Comercial" name="Nombre_Comercial" placeholder=" . . . "   >
                  </div>
				</div>
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Apellido</label>
                    <input type="email" class="form-control" id="Apellido_Comercial" name="Apellido_Comercial" placeholder=" . . . "   >
                  </div>
				</div>
				  
				  
				  
				  <div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Telefono Contacto</label>
                    <input type="email" class="form-control" id="Telefono_Comercial" name="Telefono_Comercial" placeholder=" . . . "   >
                  </div>
				</div>
				
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Telefono Movil</label>
                    <input type="email" class="form-control" id="Telefono_Movil_Comercial" name="Telefono_Movil_Comercial" placeholder=" . . . "   >
                  </div>
				</div>
				
				  
				
				<div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Correo Electrónico</label>
						<input type="email" class="form-control" id="Correo_Comercial" name="Correo_Comercial" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				  
				  
				  <div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">RUT</label>
						<input type="email" class="form-control" id="Rut_Comercial" name="Rut_Contable" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				
				</div>				  
				  </div>
				  <div class="row">
				 <div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Cargo en la Empresa</label>
						<input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  </div>  
					
				</div>	
            </div>
			
			<!-- FIN -->
			
			
			
			
			<!-- MODULO DE ENCARGADO ACCESO - CONTACTO EN BODEGAS -->
			
		
			<div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Encargado Accesos - Contacto en Bodegas</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             
                <div class="card-body">
				<div class="row">
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nombre</label>
                    <input type="email" class="form-control" id="Nombre_Bodega" name="Nombre_Bodega" placeholder=" . . . "   >
                  </div>
				</div>
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Apellido</label>
                    <input type="email" class="form-control" id="Apellido_Bodega" name="Apellido_Bodega" placeholder=" . . . "   >
                  </div>
				</div>
				  
				  
				  
				  <div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Telefono Contacto</label>
                    <input type="email" class="form-control" id="Telefono_Bodega" name="Telefono_Bodega" placeholder=" . . . "   >
                  </div>
				</div>
				  
				
				<div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Correo Electrónico</label>
						<input type="email" class="form-control" id="Correo_Electronico_Bodega" name="Correo_Electronico_Bodega" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				
				</div>				  
				  </div>
				  <div class="row">
				 <div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Cargo en la Empresa</label>
						<input type="email" class="form-control"  id="Cargo_Empresa_Bodega" name="Cargo_Empresa_Bodega" placeholder=" . . . "   >
					  </div>
					</div>
				  </div>
				  
				   <div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">RUT</label>
						<input type="email" class="form-control" id="Rut_Bodegas" name="Rut_Bodegas" placeholder=" . . . "   >
					  </div>
					</div>
				  </div>
				  
				  
				  </div>  
					
					  
					
				</div>	
            </div>
			
			<!-- FIN -->
			
			
			
			<!-- MODULO DE FACTURACION ELECTRONICA -->
			
		
			<div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Facturacion Electrónica</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             
                <div class="card-body">
				<div class="row">
				
				<div class="col-sm-6">
                  <div class="form-group">
				  <FONT SIZE=2> <em> <strong> EMITE ORDEN DE COMPRA QUE DEBE ESTAR GRABADA EN FACTURA</font> </em> </strong>
                    <label for="exampleInputEmail1"></label>
                    <input class="only-one" type="checkbox" > 
                  </div>
				</div>
				
				<div class="col-sm-6">
                  <div class="form-group"> 
				  <FONT SIZE=2><em> <strong> EMITE HES O RECEPCIÓN QUE DEBA ESTAR GRABADA EN FACTURA</font> </em> </strong>
                    <input class="only-one" type="checkbox" > 
                  </div>
				</div>
				  				  
				</div>				  
				  </div>
				  
					
				</div>	
            </div>
			
			<!-- FIN -->
			
						
			<!-- FIN -->
			
			
			
			
			
			</div>
		  	  
		  
		  <div class="col-sm-12">
			<div class="card-footer ">
				
				<input type="submit" name="enviar">
                <button type="submit" class="btn btn-danger float-left">Ingresar Formulario </button>
				<button type="submit" class="btn btn-danger float-right">Cancelar</button>
				</div>
            </div>	  
	  
		</section>
					
			

			<!-- FIN -->
		</div>
			
			
						
		</div>
		
	</form>
	
		<!-- copy of input fields group -->


<div class="form-group fieldGroupCopy2" style="display: none;">
    <div class="input-group">
				
		<div class="card-header danger">
                <h3 class="card-title">Representante Legal</h3>      
		</div>
				
			<div class="row">
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nombre</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
                  </div>
				</div>
				
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Apellido</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
                  </div>
				</div>
				
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nacionalidad</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
                  </div>
				</div>
				
				<div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Estado Civil</label>
						<input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				
			</div>
				
				<div class="row">
				
				
				
				
				<div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Profesion</label>
						<input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				 <div class="col-sm-6">
				  <div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">R.U.T</label>
						<input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
					  </div>
					</div>
				</div>
				
			</div>
			
			
			<div class="row">
			
			<div class="col-sm-6">
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Telefono</label>
						<input type="email" class="form-control" id="Telefono_Legal" name="Telefono_Legal" placeholder=" . . . "   >
					  </div>
					</div>
				
				  </div>
				  
				  
				  <div class="col-sm-6">
                     
					<div class="col-sm-12">
					  <div class="form-group">
						<label for="exampleInputEmail1">Correo Electronico</label>
						<input type="email" class="form-control" id="Email_Legal" name="Email_Legal" placeholder=" . . . "   >
					  </div>
					</div>
				 
                    </div>
			
			
			</div>
			
			
			<div class="row">
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nombre notario firma acta</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder=" . . . "   >
                  </div>
				</div>
				
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Fecha de constitucion de empresa</label>
                    <input type="date" class="form-control" id="exampleInputEmail1">
                  </div>
				</div>
				</div>	
			
				
			<div class="card-header danger">
                <h3 class="card-title">* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  </h3>      
			</div>	
		
        <div class="input-group-addon"> 
            <a href="javascript:void(0)" class="btn btn-danger remove"><span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span> </a>
        </div>
    </div>
</div>
	
	
	
	
	
		
		<div class="row"> 
			<div class="borde color4 col-sm-12"> FOOTER </div>
		
		</div>
		
		
	</div>
  
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <!-- <script src="../js/bootstrap.min.js"></script> -->

	
	<!-- jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- Select2 -->
	<script src="plugins/select2/js/select2.full.min.js"></script>
	<!-- Bootstrap4 Duallistbox -->
	<script src="plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>

	<!-- bootstrap color picker -->
	<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
	<!-- Tempusdominus Bootstrap 4 -->
	<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
	<!-- Bootstrap Switch -->
	<script src="plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
	<!-- AdminLTE App -->
	<script src="dist/js/adminlte.min.js"></script>
	<!-- AdminLTE for demo purposes -->
	<script src="dist/js/demo.js"></script>


<script>
	window.onload = function(){
		var contador = 0;
		document.getElementById("cmbx_Bodega").onclick = function(){
			contador ++;
			var Cont1 = Math.round(contador /2);
			document.getElementById("mostrar").innerHTML = Cont1;
		}		

	}



</script>


<script> 
	function miFuncion(){

		var Bodega = document.getElementById("cmbx_Bodega").value;
		document.getElementById("tutorial").innerHTML += Bodega + ",";

	}

</script>


<script> 
	function miFuncion1(){
		var suma = 0;
		var Bodega = parseInt(document.getElementById("cmbx_M2").value);
		
		var suma = parseInt(suma+Bodega);
		
		document.getElementById("SuperficieM2").innerHTML = suma  ;

		
		
	}
</script>

<script type="text/javascript">
	document.addEventListener('DOMContentLoaded', function(){
	var suma = 0;
	document.getElementById('cmbx_M2').addEventListener('change', function(){
	suma += parseInt(this.value);
	document.getElementById('sumaM2').innerHTML = suma;
});
});

</script>


<script>
	function solonumeros(e){
		key=e.keyCode || e.which;
		
		teclado=String.fromCharCode(key);
		
		numeros="0123456789";
		
		especiales = "8-34-38-46-188-110-44";
		
		teclado_especial=false;
		
		for(var i in especiales){
			if(key==especiales[i]){
				teclado_especial=true;
				
				
			}
			
		}
		
		if(numeros.indexOf(teclado)==-1 && !teclado_especial){
			return false;
			
			
		}
		
	}


</script>

<script>
function validateDecimal(valor) {
    var RE = /^\d*(\.\d{1})?\d{0,1}$/;
    if (RE.test(valor)) {
        return true;
    } else {
        return false;
    }
}
</script>



<script type="text/javascript">

function filterFloat(evt,input){
    // Backspace = 8, Enter = 13, ‘0′ = 48, ‘9′ = 57, ‘.’ = 46, ‘-’ = 43
    var key = window.Event ? evt.which : evt.keyCode;    
    var chark = String.fromCharCode(key);
    var tempValue = input.value+chark;
    if(key >= 48 && key <= 57){
        if(filter(tempValue)=== false){
            return false;
        }else{       
            return true;
        }
    }else{
          if(key == 8 || key == 13 || key == 0 || key == 37) {     
              return true;              
          }else if(key == 46){
                if(filter(tempValue)=== false){
                    return false;
                }else{       
                    return true;
                }
          }else{
              return false;
          }
    }
}
function filter(__val__){
    var preg = /^([0-9]+\.?[0-9]{0,2})$/; 
    if(preg.test(__val__) === true){
        return true;
    }else{
       return false;
    }
    
}

</script>


<script type="text/javascript">
window.onload = function(){
    fecha = new Date();
    texto = document.getElementById("fechaing");
    texto.value = fecha.getDate()+"/"+(fecha.getMonth()+1)+"/"+fecha.getFullYear();
}
</script>


<script>

var obj=document.getElementById('MyDate');
var obj2 = document.getElementById('MyDate2');
var obj3 = document.getElementById('MyDate3');
obj.value = setFormato(new Date());

function AddMes(){
 var fecha = new Date(obj.value);
 fecha.setMonth( fecha.getMonth() + +(obj2.value));
 obj3.value = setFormato(fecha);
}

function setFormato(fecha){
    var day = ("0" + fecha.getDate()).slice(-2);
    var month = ("0" + (fecha.getMonth() + 1)).slice(-2);
    var date = (day)+"-"+(month)+"-"+fecha.getFullYear();
    return date;
}

</script>






  </body>
</html>