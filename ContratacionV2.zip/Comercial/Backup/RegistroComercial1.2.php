<?php
date_default_timezone_set("America/Santiago");
session_start();
include("../Conexion/conexion_sql_server.php");
#include("../Conexion/conexion_sql_server_7.php");

?>

<!doctype html>
<html lang="en">
  <head>
  
		<!-- Estilos en CSS -->
	<style>
		.borde{border: 1px #000 solid; text-align:center; heigth: 50px;}
		.color1{background: #eeeeee;}
		.color2{background: #f6f6f6;}
		.color3{background: #94ac3c;}
		.color4{background: #295ba7;}
	
	</style>


	<title> Area Comercial 1</title>
    <!-- Required meta tags -->
    <link rel="shortcut icon" href="../images/favicon.ico"/>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
	

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">


<!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Bootstrap4 Duallistbox -->
  <link rel="stylesheet" href="plugins/bootstrap4-duallistbox/bootstrap-duallistbox.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
	
	


  <script language="javascript" src="../js/jquery-3.4.1.min.js"> </script>
  
  <!-- SCRIPT PARA LA FUNCION DE LOS RANGOS -->
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<!-- CODIGO JQUERY -->
	
	
	

<!-- PROCESO DE ADICIONAR LAS BODEGAS -->

<script>

 $(document).ready(function() {
	 	 
//obtenemos el valor de los input

$('#adicionar').click(function() {
	
  var nombre = document.getElementById("NombreBodega").value;
  var apellido = document.getElementById("M2").value;
  var sumatoria = document.getElementById("Sumatoria");
  var i = 1; //contador para asignar id al boton que borrara la fila
    
  var fila = ' <tr id="row' + i + '"><td>' + nombre + '</td><td id ="apellido'+ i + '" >' + apellido + '</td><td><button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_remove">Quitar</button></td></tr> '; //esto seria lo que contendria la fila
  
  i++;
  
	var _M2 = parseInt(document.getElementById("M2").value);
	
	sumatoria.value = parseInt(sumatoria.value) + _M2;
	
	
	
  $('#mytable tr:first').after(fila);
    $("#adicionados").text(""); //esta instruccion limpia el div adicioandos para que no se vayan acumulando
    var nFilas = $("#mytable tr").length;
    $("#adicionados").append(nFilas - 1);
    //le resto 1 para no contar la fila del header
    document.getElementById("apellido").value ="";
    document.getElementById("cedula").value = "";
    document.getElementById("nombre").value = "";
    document.getElementById("nombre").focus();
	
	
	
  });
$(document).on('click', '.btn_remove', function() {
  var button_id = $(this).attr("id");
  
  var ap =  document.getElementById("apellido"+button_id);
  alert("Se han quitado: " + ap.innerText + " M2");
  
  var sumatoria = document.getElementById("Sumatoria");
  
  sumatoria.value = parseInt(sumatoria.value) - parseInt(ap.innerText);
  
    //cuando da click obtenemos el id del boton
    $('#row' + button_id + '').remove(); //borra la fila
    //limpia el para que vuelva a contar las filas de la tabla
    $("#adicionados").text("");
    var nFilas = $("#mytable tr").length;
    $("#adicionados").append(nFilas - 1);
  });
  
  
  
  
});

</script>


<script>
$(document).on('change', '#cmbx_M2', function(event) {
     $('#M2').val($("#cmbx_M2 option:selected").text());
   	 
});
</script>

<!-- FIN-->

<script>
$(document).on('change', '#cmbx_Bodega', function(event) {
     $('#NombreBodega').val($("#cmbx_Bodega option:selected").text());	 
});
</script>

<script>
$(document).on('change', '#cmbx_Cotizacion_Activa', function(event) {
     $('#NumCotizacion').val($("#cmbx_Cotizacion_Activa option:selected").text());	 
});
</script>


<script>
$(document).on('change', '#cmbx_Cotizacion_Activa', function(event) {
     $('#caja_busqueda').val($("#cmbx_Cotizacion_Activa option:selected").text());	 
});
</script>





<!-- SCRIPT PARA RELLENAR LOS SELECT DE BODEGA Y M2 -->
<script language = "javascript">
			$(document).ready(function () {
				$("#cmbx_Centro_Logistico_V2 ").change(function () {

				$("#cmbx_Centro_Logistico_V2 option:selected" ).each(function (){
					CEN_CODIGO = $(this).val();
		
					$.post("includes/getBodegas.php", { CEN_CODIGO: CEN_CODIGO
					}, function(data){
						$("#cmbx_Bodega").html(data);
});
});
});
});

			$(document).ready(function () {
				$("#cmbx_Bodega").change(function () {

				$("#cmbx_Bodega option:selected").each(function (){
					
					BODE_NROBODEGA = $(this).val();
					
					var valor = $(cmbx_Centro_Logistico_V2).val();
					

					$.post("includes/getM2.php", { BODE_NROBODEGA: BODE_NROBODEGA , valor: valor 
					}, function(data){
						$("#cmbx_M2").html(data);
					});
				});
			});
		});

</script>

<!-- FIN-->

<!-- SCRIPT QUE HABILITA LOS INPUT -->
<script>
		function habilitar(value)
		{
			if(value==true)
			{
				// habilitamos
				document.getElementById("AnexoContrato").disabled=false;
				document.getElementById("NumeroContrato").disabled=false;
			}else if(value==false){
				// deshabilitamos
				document.getElementById("AnexoContrato").disabled=true;
				document.getElementById("NumeroContrato").disabled=true;
			}
		}
</script>
<!-- FIN -->

<!-- SCRIPT PARA OBTENER EL NOMBRE DE LA EMPRESA BY RUT -->
<script language = "javascript">
	$(document).ready(function(){
		$("#cmbx_Rut_Empresa").change(function() {
			$("#cmbx_Rut_Empresa option:selected").each(function () {
				Rut_Empresa = $(this).val();
				$.post("includes/getNombreEmpresa.php", { Rut_Empresa: Rut_Empresa 
				}, function(data){
					$("#cmbx_Nombre_Empresa").html(data);
				});
			});
		});
	});
	
</script>
<!-- FIN -->

<!-- SCRIPT PARA OBTENER LAS COTIZACIONES ACTIVAS BY RUT -->
<script language = "javascript">
	$(document).ready(function(){
		$("#cmbx_Rut_Empresa").change(function() {
			$("#cmbx_Rut_Empresa option:selected").each(function () {
				Rut_Empresa = $(this).val();
				$.post("includes/getCotizacionesActivas.php", { Rut_Empresa: Rut_Empresa
				}, function(data){
					$("#cmbx_Cotizacion_Activa").html(data);
				});
			});
		});
	});
</script>
<!-- FIN -->


<!-- SCRIPT PARA OBTENER EL NOMBRE DE CONTACTO BY RUT -->

<script language = "javascript">
	$(document).ready(function(){
		$("#cmbx_Rut_Empresa").change(function() {
			$("#cmbx_Rut_Empresa option:selected").each(function () {
				Rut_Empresa = $(this).val();
				$.post("includes/getNombreContacto.php", { Rut_Empresa: Rut_Empresa
				}, function(data){
					$("#cmbx_Nombre_Contacto").html(data);
				});
			});
		});
	});
</script>

<!-- FIN -->


<!-- SCRIPT PARA OBTENER EL CORREO DEl CONTACTO BY RUT -->

<script language = "javascript">
	$(document).ready(function(){
		$("#cmbx_Rut_Empresa").change(function() {
			$("#cmbx_Rut_Empresa option:selected").each(function () {
				Rut_Empresa = $(this).val();
				$.post("includes/getCorreoContacto.php", { Rut_Empresa: Rut_Empresa
				}, function(data){
					$("#cmbx_Correo_Contacto").html(data);
				});
			});
		});
	});
</script>

<!-- FIN -->


<!-- SCRIPT PARA OBTENER EL TELEFONO DEl CONTACTO BY RUT -->
<script language = "javascript">
	$(document).ready(function(){
		$("#cmbx_Rut_Empresa").change(function() {
			$("#cmbx_Rut_Empresa option:selected").each(function () {
				Rut_Empresa = $(this).val();
				$.post("includes/getTelefonoContacto.php", { Rut_Empresa: Rut_Empresa
				}, function(data){
					$("#cmbx_Telefono_Contacto").html(data);
				});
			});
		});
	});
</script>

<!-- FIN -->


<!-- SCRIPT PARA OBTENER EL TELEFONO MOVIL DEl CONTACTO BY RUT -->

<script language = "javascript">
	$(document).ready(function(){
		$("#cmbx_Rut_Empresa").change(function() {
			$("#cmbx_Rut_Empresa option:selected").each(function () {
				Rut_Empresa = $(this).val();
				$.post("includes/getFaxContacto.php", { Rut_Empresa: Rut_Empresa
				}, function(data){
					$("#cmbx_Fax_Contacto").html(data);
				});
			});
		});
	});
</script>


<!-- FIN -->



<!-- SCRIPT PARA OBTENER EL CENTRO LOGISTICO BY COTIZACION -->

<script language = "javascript">
	$(document).ready(function(){
		$("#cmbx_Cotizacion_Activa").change(function() {
			$("#cmbx_Cotizacion_Activa option:selected").each(function () {
				Cotizacion = $(this).val();
				$.post("includes/getCentroLogistico_By_Cotizacion.php", { Cotizacion: Cotizacion
				}, function(data){
					$("#cmbx_Centro_Logistico_V2").html(data);
				});
			});
		});
	});
</script>
<!-- FIN -->



<!-- SCRIPT PARA OBTENER EL DESCUENTO PRONTO PAGO BY COTIZACION -->
<script language = "javascript">
	$(document).ready(function(){
		$("#cmbx_Cotizacion_Activa").change(function() {
			$("#cmbx_Cotizacion_Activa option:selected").each(function () {
				Cotizacion = $(this).val();
				$.post("includes/getDescuentoPP_By_Cotizacion.php", { Cotizacion: Cotizacion
				}, function(data){
									
					$('#DescuentoPP5_V2').val(data);
					$('#DescuentoPP8_V2').val(data);
					$('#DescuentoPP10_V2').val(data);
					
				});
			});
		});
	});
</script>

<!-- FIN -->


<!-- SCRIPT PARA BUSCAR LA RENTA EN UF -->

<script language = "javascript">
	$(document).ready(function(){
		$("#cmbx_Cotizacion_Activa").change(function() {
			$("#cmbx_Cotizacion_Activa option:selected").each(function () {
				Cotizacion = $(this).val();
				$.post("includes/getRentaMensualUF.php", { Cotizacion: Cotizacion
				}, function(data){
									
					$('#RentaMensualUF2').val(data);
					
				});
			});
		});
	});
</script>


<!-- FIN -->



<script type="text/javascript">
$(document).ready(function() {
    $('input[type=checkbox]').live('click', function(){
        var parent = $(this).parent().attr('id');
        $('#'+parent+' input[type=checkbox]').removeAttr('checked');
        $(this).attr('checked', 'checked');
    });
});
</script>

<script>
 let Checked = null;
//The class name can vary
for (let CheckBox of document.getElementsByClassName('only-one')){
	CheckBox.onclick = function(){
  	if(Checked!=null){
      Checked.checked = false;
      Checked = CheckBox;
    }
    Checked = CheckBox;
  }
}
</script>

<script>

var obj=document.getElementById('MyDate');
var obj2 = document.getElementById('MyDate2');
var obj3 = document.getElementById('MyDate3');
obj.value = setFormato(new Date());

function AddMes(){
 var fecha = new Date(obj.value);
 fecha.setMonth( fecha.getMonth() + +(obj2.value));
 obj3.value = setFormato(fecha);
}

function setFormato(fecha){
    var day = ("0" + fecha.getDate()).slice(-2);
    var month = ("0" + (fecha.getMonth() + 1)).slice(-2);
    var date = (day)+"-"+(month)+"-"+fecha.getFullYear();
    return date;
}

</script>





<script type="text/javascript">

		function delimitarMesesRenovacion(event) {
			$(document).on('keyup', '#MesesRenovacion', function(event) {
			let max= parseInt(this.max);
			let valor = parseInt(this.value);
				if(valor>max){
					alert("Valor No Permitido");
					this.value = max;
				}
			});
	}
</script>



<script type="text/javascript">

		function delimitarPlazoContrato(event) {
			$(document).on('keyup', '#MyDate2', function(event) {
			let max= parseInt(this.max);
			let valor = parseInt(this.value);
				if(valor>max){
					alert("Valor No Permitido");
					this.value = max;
				}
			});
	}
</script>




<script type="text/javascript">

		function validaNumericos(event) {
			
			var TheFomrs = document.getElementById('MyDate2');
			//var Meses12 = 12;

			if(TheFomrs.value <= 12){
			
			if(event.charCode >= 46 && event.charCode <= 57){
				document.getElementById('DescuentoPP5').style.display='block';
				document.getElementById('DescuentoPP8').style.display='none';
				document.getElementById('DescuentoPP10').style.display='none';
				
				
			return true;
			}
			
			//
			
			$(document).on('keyup', '#DescuentoPP5', function(event) {
			let max= parseInt(this.max);
			let valor = parseInt(this.value);
				if(valor>max){
					alert("Valor No Permitido");
					this.value = max;
				}
			});
			
			return false; 
			
			//
		
			
			return false;			       
		}
		
		
		
		if(TheFomrs.value >= 12 && TheFomrs.value <= 36){
			
			if(event.charCode >= 46 && event.charCode <= 57){
				
				document.getElementById('DescuentoPP5').style.display='none';
				document.getElementById('DescuentoPP8').style.display='block';
				document.getElementById('DescuentoPP10').style.display='none';
				
				
				
				
			return true;
			}
			
			//
			
			$(document).on('keyup', '#DescuentoPP8', function(event) {
			let max= parseInt(this.max);
			let valor = parseInt(this.value);
				if(valor>max){
					alert("Valor No Permitido");
					this.value = max;
				}
			});
			
			return false; 
			
			//
			
			
			return false;        
		}
		
		
		if(TheFomrs.value >= 36 ){
			
			if(event.charCode >= 46 && event.charCode <= 57 ){
				
				document.getElementById('DescuentoPP5').style.display='none';
				document.getElementById('DescuentoPP8').style.display='none';
				document.getElementById('DescuentoPP10').style.display='block';
				
			return true;
				
			}
			
			//
			
			$(document).on('keyup', '#DescuentoPP10', function(event) {
			let max= parseInt(this.max);
			let valor = parseInt(this.value);
				if(valor>max){
					alert("Valor No Permitido");
					this.value = max;
				}
			});
			
			return false; 
			
			//
			
			
			
			return false;        
		}		
	}
	
</script>	


<!-- SCRIPT PARA VALIDAR LOS INPUTS DE DESCUENTO PRONTO PAGO V2 -->

<script type="text/javascript">

		function validaNumericos2(event) {
			
			var TheFomrs = document.getElementById('MyDate2');
			//var Meses12 = 12;

			if(TheFomrs.value <= 12){
			
			document.getElementById('DescuentoPP8_V2').style.display='none';
			document.getElementById('DescuentoPP10_V2').style.display='none';
			
			if(event.charCode >= 46 && event.charCode <= 57){
				document.getElementById('DescuentoPP5_V2').style.display='block';
				//document.getElementById('DescuentoPP8_V2').style.display='none';
				//document.getElementById('DescuentoPP10_V2').style.display='none';
				
				
			return true;
			}
			
			//
			
			$(document).on('keyup', '#DescuentoPP5_V2', function(event) {
			let max= parseInt(this.max);
			let valor = parseInt(this.value);
				if(valor>max){
					alert("Valor No Permitido");
					this.value = max;
				}
			});
			
			return false; 
			
			//
		
			
			return false;			       
		}
		
		
		
		if(TheFomrs.value >= 12 && TheFomrs.value <= 36){
			
			document.getElementById('DescuentoPP5_V2').style.display='none';
			document.getElementById('DescuentoPP10_V2').style.display='none';
			
			if(event.charCode >= 46 && event.charCode <= 57){
				
				document.getElementById('DescuentoPP8_V2').style.display='block';
				
			return true;
			}
			
			//
			
			$(document).on('keyup', '#DescuentoPP8_V2', function(event) {
			let max= parseInt(this.max);
			let valor = parseInt(this.value);
				if(valor>max){
					alert("Valor No Permitido");
					this.value = max;
				}
			});
			
			return false; 
			
			//
			
			
			return false;        
		}
		
		
		if(TheFomrs.value >= 36 ){
			
			document.getElementById('DescuentoPP5_V2').style.display='none';
			document.getElementById('DescuentoPP8_V2').style.display='none';
			
			if(event.charCode >= 46 && event.charCode <= 57 ){
				
				document.getElementById('DescuentoPP10_V2').style.display='block';
				
			return true;
				
			}
			
			//
			
			$(document).on('keyup', '#DescuentoPP10_V2', function(event) {
			let max= parseInt(this.max);
			let valor = parseInt(this.value);
				if(valor>max){
					alert("Valor No Permitido");
					this.value = max;
				}
			});
			
			return false; 
			
			//
			
			
			
			return false;        
		}		
	}
	
</script>	

<!-- SCRIPT PARA BUSCAR LOS DATOS ADICIONALES DE UNA BODEGA A UN JSON -->
<script>
function BuscarAdicionales() {
	var Cotizacion = document.getElementById("NumCotizacion").value;
	alert("Buscando los Adicionales de Bodegas de la Cotizacion: " + Cotizacion);
	
	
	
	
}
</script>


<!-- FIN -->

<!-- FIN -->
    
  </head>
  <body>
	<div class="container">
		<div class="row"> 
			<div class="borde color4 col-sm-12">HEADER </div>
		
		</div>	
		<div class="row"> 
			
 <div class="borde color2 col-sm-12 col-md-12">Registro de Contrato Comercial  
			
				<!-- CONTENIDO -->
			
	<section class="content">
	 <form id="RegistroComercial" name="RegistroComercial" action="RegistroClienteWeb" method="POST">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-12">
            <!-- general form elements disabled -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Informacion de Empresa</h3>
              </div>
              <!-- /.card-header -->
			
              <div class="card-body">
			  
			   <div class="row">
			   
				<div class="col-sm-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Numero Resumen Contrato</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Numero de Contrato" disabled>
                  </div>
				</div>
			   
			   
				<div class="col-sm-6">
                      <div class="form-check">
                          <input class="only-one" type="checkbox" > 
                          <label class="exampleInputEmail1">Contrado Nuevo</label>  
                        </div>
						
						
						 
                      <div class="form-check">
                          <input class="only-one" type="checkbox" onchange="habilitar(this.checked);"> 
                           <label class="exampleInputEmail1">Anexo de Contrato </label> 
                        </div>
                    
						
                </div>
			   
			   
			   </div>
			   
			   
			    <div class="row">
                    <div class="col-sm-6">
                      <!-- textarea -->
                      <div class="form-group">
                        <label>Numero de Contrato</label>
                        <input type="text" class="form-control" placeholder="Anexo Contrato"  id="AnexoContrato" disabled >
                      </div>				  
					  
                    </div>
					
					
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Anexo Contrato</label>
                        <input type="text" class="form-control" placeholder="Numero de Contrato" id="NumeroContrato" disabled >
                      </div>
                    </div>
                  </div>
			  
                  <div class="row">			
					
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>R.U.T. Empresa</label>                      
						<select id="cmbx_Rut_Empresa" name="cmbx_Rut_Empresa" class="form-control select2" style="width: 100%;">
						<option value="0"> Seleccione Rut del Cliente </option>
						
						<!-- CODGIDO PHP -->
						<?php
														
							$serverName="BDBSF\BDBSF";
							$connectionInfo = array("Database"=> "BSFCotizaciones", "UID"=>"sa", "PWD"=>"m@sterkey", "CharacterSet"=>"UTF-8");
							$con7 = sqlsrv_connect($serverName, $connectionInfo);
							
							$MyQuerry = "SELECT distinct RUT_EMPRESA, DV_EMPRESA FROM MAECOTIZA WHERE (RUT_EMPRESA <> 0) order by RUT_EMPRESA";
							$resultado = sqlsrv_query($con7, $MyQuerry);

							while($valores= sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)){
							$Rut_Empresa_DV = $valores['RUT_EMPRESA']. "-".$valores['DV_EMPRESA'] ;
							$Rut_Empresa = $valores['RUT_EMPRESA'] ;
							
							echo '<option value = "'.$Rut_Empresa.'" > '.$Rut_Empresa_DV.' </option>';
							}
							
							sqlsrv_close();
						?>
						
						</select>
						<p id ="resultado11">
                      </div>
                    </div>					
					
					<div class="col-sm-6">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Nombre de Empresa</label>
                        <!-- <input type="text" class="form-control"  id="NombreEmpresa" placeholder="Nombre Empresa" disabled> -->
						<select class="form-control select2" id="cmbx_Nombre_Empresa" name="cmbx_Nombre_Empresa"> 
							<option value="0"> Seleccione la empresa </option>
						</select>				
                      </div>  
                    </div>
					
					
                  </div>
				  
				  
				  
				  <div class="row">	
					<div class="col-sm-6">
						<div class="form-group">
							<label>Número de Cotizacion</label>						
							<select id="cmbx_Cotizacion_Activa" name="cmbx_Cotizacion_Activa" class="form-control select2" >
							<option value="0"> Seleccione la Cotizacion </option> 
						</select>
                      </div>
				   </div>
				   
				   <div class="col-sm-6">
						<div class="form-group">
							<label>Nombre de Contacto</label>						
							<select id="cmbx_Nombre_Contacto" name="cmbx_Nombre_Contacto" class="form-control select2" >
							<option value="0"> Seleccione el contacto </option> 
						</select>
                      </div>
				   </div>
				  
				  
				  </div>
				  
				  
				  
				  
				   <div class="row">	
					<div class="col-sm-6">
						<div class="form-group">
							<label>Correo de Contacto</label>						
							<select id="cmbx_Correo_Contacto" name="cmbx_Correo_Contacto" class="form-control select2" >
							<option value="0"> Seleccione el correo </option> 
						</select>
                      </div>
				   </div>
				   
				   <div class="col-sm-3">
						<div class="form-group">
							<label>Telefono de Contacto</label>						
								<select id="cmbx_Telefono_Contacto" name="cmbx_Telefono_Contacto" class="form-control select2" >
									<option value="0"> Seleccione el telefono </option> 
								</select>
						</div>
					</div>
					  
					  <div class="col-sm-3">
						<div class="form-group">
							<label>Telefono Móvil</label>						
								<select id="cmbx_Fax_Contacto" name="cmbx_Fax_Contacto" class="form-control select2" >
									<option value="0"> Seleccione el móvil </option> 
								</select>
						</div>
					  </div>
				  </div>
				  
				  
				  
				  
				  
				  
                 
                  <!-- input states -->    
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            <!-- general form elements disabled -->
            
            <!-- /.card -->
          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
	  
	    <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Informacion Bodega</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             
                <div class="card-body">
				<div class="row">
				<div class="col-sm-6">

				<div class="form-group">
                  <label>Centro Logistico</label>
                  <select id="cmbx_Centro_Logistico" name="cmbx_Centro_Logistico" class="form-control select2" style="width: 100%;">
						<option value="0"> Seleccione Centro Logistico </option>

						<!-- CODGIDO PHP -->
						<?php
								
							
							$MyQuerry = "select CEN_CODIGO, CEN_NOMBRE FROM tbl_CENTRO";
							$resultado = sqlsrv_query($con, $MyQuerry);

							while($valores= sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)){
							$codigo = $valores['CEN_CODIGO'];
							$nombre = $valores['CEN_NOMBRE'];

							echo '<option value = "'.$valores['CEN_CODIGO'].'" > '.$valores['CEN_NOMBRE'].' </option>';

							}
							#sqlsrv_close($con7);
						?>
						<!-- FIN -->
                  </select>
				  
				  <select id="cmbx_Centro_Logistico_V2" name="cmbx_Centro_Logistico_V2" class="form-control select2" style="width: 100%;">
						<option value="0"> Seleccione Centro Logistico V2</option>
				  </select>
                </div>
				</div>
				  
				  
				  
				  
				  <div class="col-sm-6">
                      <div class="form-check">
							<label class="form-check-label">Fecha Inicio</label>
							
							<input type="date" id="MyDate" class="form-control"   value="fechaing" >
                        </div>
                    </div>
				  </div>

				  <div class="row">
				  
				 <div class="col-sm-6">
					
					<div class="form-group"> 
						<label> Selecciona la Bodega: </label>
						<select class="form-control select2" onchange="miFuncion()" id="cmbx_Bodega" name="cmbx_Bodega" style="width: 80%;"> 
							<option value="0"> Seleccione la Bodega </option>
						</select>
						 
						<input type="hidden" id="NombreBodega" name="NombreBodega" >
								
					</div>
				 </div>
				   
				  <div class="col-sm-6">
                      <div class="form-check">
                          <label class="form-check-label">Plazo de Contrato </label>
						   <input type="number" class="form-control" id="MyDate2"  name="MyDate2" placeholder="60" onkeypress="return delimitarPlazoContrato(event)" maxlength="2" max="60" min="1" onChange="AddMes()"> 
						   
                        </div>
                    </div>
				  </div>    
				 
				 <div class="row">
				  <div class="col-sm-6">
				    
					<div class="form-group">
                    <label for="exampleInputEmail1">Superfice M2</label>
					<select class="form-control select2" id="cmbx_M2" name="cmbx_M2" onchange="miFuncion1()" onkeyup="busqueda();">
						<option value="0"> Seleccione la opcion </option>


					</select>
					
					<input type="hidden" id="M2" name="M2" >
				
					<!-- <label id="sumaM2"> </label> -->
					
					
                  </div>
				  
				  
				  <button id="adicionar" class="btn btn-success" type="button">Agregar</button>
						 <p>Numero de Bodegas Agregadas:
					  <div id="adicionados"></div>
					</p>
					<table id="mytable" class="table table-bordered table-hover">
					  <tr>
						<th>Bodega</th>
						<th>M2</th>
						<th>Eliminar</th>
					  </tr>
					</table>
					
					
					<p>Total M2 Seleccionados: </p>
					<input  id="Sumatoria" name="Sumatoria" value = "0" readonly="readonly">
					<br>
					<br>
				  
				  </div>
				  
				  
				
				  
				  
				 

				  <div class="col-sm-6">
                      <div class="form-check">
                          <label class="form-check-label">Fecha Termino </label>
						  
						  <input  id="MyDate3" class="form-control" placeholder="Resultado final" disabled >
                        </div>
                    </div>
				</div>
				
				
				 
				 
				 <div class="row"> 
				  <div class="col-sm-6">
                  
				  <div class="form-group">
                  <label>Meses Plazo Aviso</label>
                  <select class="form-control select2" style="width: 100%;">
						
						<!-- CODGIDO PHP -->
						<?php
							$MyQuerry1 = "SELECT * FROM tbl_PLAZO_AVISO";
							$resultado1 = sqlsrv_query($con, $MyQuerry1);

							while($valores1= sqlsrv_fetch_array($resultado1, SQLSRV_FETCH_ASSOC)){
							$codigo1 = $valores1['COD_PLAZO'];
							$nombre1 = $valores1['NOMBRE_PLAZO'];

							echo '<option value = "'.$codigo1.'" > '.$nombre1.' </option>';
							}
						?>
						<!-- FIN -->
                  </select>
                </div>
				  
				  
				  </div>
				  	  
				  <div class="col-sm-6">
                      <div class="form-check">
                          <label class="form-check-label">Meses Renovación </label>
						  <input type="number" class="form-control" id="MesesRenovacion" name ="MesesRenovacion" max="60" min="1"placeholder="60" onkeypress="return delimitarMesesRenovacion(event)" maxlength="1">
                        </div>
                    </div>				  
				  </div>
				 
				  <div class="row"> 
				  
				  <div class="col-sm-6">
                 
					<div class="form-check">
                          <label class="form-check-label">Monto Garantia (UF) </label>
						  <!-- <input type="float" class="form-control" id="exampleInputEmail1" placeholder="99999.99" onkeypress="return filterFloat2(event,this)" maxlength="8" > -->
						  <input step="0.01" type="number" class="form-control" id="MontoGarantialUF" name="MontoGarantialUF" placeholder="99999.99" onkeypress="return validaNumericos(event)" max="99999" >
                        </div>
				 
				 
				  </div>
				
				
				
				
				  <div class="col-sm-6">
					
					<div class="form-group">
                    <label for="exampleInputEmail1">Renta Mensual (UF)</label>
                   <!-- <input type="float" class="form-control" id="exampleInputEmail1" placeholder="9999.99" onkeypress="return filterFloat2(event,this)" maxlength="8" > -->
					<input step="0.01" type="number" class="form-control" id="RentaMensualUF" name="RentaMensualUF" placeholder="99999.99" onkeypress="return validaNumericos(event)" max="99999" >
                  </div>


					<div class="form-group">
                    <label for="exampleInputEmail1">Renta Mensual (UF) V2</label>
                   <!-- <input type="float" class="form-control" id="exampleInputEmail1" placeholder="9999.99" onkeypress="return filterFloat2(event,this)" maxlength="8" > -->
					<input step="0.01" type="number" class="form-control" id="RentaMensualUF2" name="RentaMensualUF2" placeholder="99999.99" onkeypress="return validaNumericos(event)" max="99999" >
                  </div>



                   </div>
				  
				  </div>			 
				 <div class="row">
				  
				  <div class="col-sm-6">
					
				<div class="form-group">
                    <label for="exampleInputEmail1">Descuento PP</label>
                   <!-- <input type="text" class="form-control" id="DescuentoPP" name = "DescuentoPP" placeholder="99,99" onkeypress="return filterFloat2(event,this)" maxlength="5" > -->
				   
					<input step="0.01" type="number" class="form-control" id="DescuentoPP5" name="DescuentoPP5" placeholder="5" onkeypress="return validaNumericos(event)" max="5" >
	 
					<input step="0.01" type="number" class="form-control" id="DescuentoPP8" name="DescuentoPP8" placeholder="7.5" onkeypress="return validaNumericos(event)" max="7.5" >
	 
					<input step="0.01" type="number" class="form-control" id="DescuentoPP10" name="DescuentoPP10" placeholder="10" onkeypress="return validaNumericos(event)" max="10" >
				   
				   
                 </div>
				 
				 <div class="form-group">
                    <label for="exampleInputEmail1">Descuento PP V2</label>
                   <!-- <input type="text" class="form-control" id="DescuentoPP" name = "DescuentoPP" placeholder="99,99" onkeypress="return filterFloat2(event,this)" maxlength="5" > -->
				   
					<input step="0.01" type="number" class="form-control" id="DescuentoPP5_V2" name="DescuentoPP5_V2" placeholder="5" onkeypress="return validaNumericos2(event)" max="5" >
	 
					<input step="0.01" type="number" class="form-control" id="DescuentoPP8_V2" name="DescuentoPP8_V2" placeholder="7.5" onkeypress="return validaNumericos2(event)" max="7.5" >
	 
					<input step="0.01" type="number" class="form-control" id="DescuentoPP10_V2" name="DescuentoPP10_V2" placeholder="10" onkeypress="return validaNumericos2(event)" max="10" >
				   
				   
                 </div>
					
					
				  </div>
				  	  
				  <div class="col-sm-6">
                      
                    </div>  
				  
				 </div>
				  
				 <div class ="row">
				<div class="col-sm-12">
					<div class="form-check">
						<label class="form-check-label">Número Cotizacion Selecciona: </label>
						<input  id="NumCotizacion" name="NumCotizacion" class="form-control" placeholder="Cotizacion" disabled >
                    </div>
				
					<section class="principal">

					<p>Cotizacion con Adicionales</p>

						<div class="formulario">
							<label for="caja_busqueda">Buscar</label>
							<input type="text" name="caja_busqueda" id="caja_busqueda"></input>							
						</div>
						<div id="datos"></div>
					</section>		
				</div>
			</div> 
				  
				 
                </div>
                   				   
            </div>
			
          </div>
		  
		  
		  
		  
		
			 <div class="card-footer ">
                  <button type="submit" class="btn btn-danger float-left">Enviar Formulario Cliente</button>
				  <button type="reset" class="btn btn-danger float-center">Cancelar</button>
                  <button type="submit" class="btn btn-danger float-right">Modificar Datos Clientes</button>
                </div>	  
	  
			</form>
		</section>
					
			

			<!-- FIN -->
		</div>
			
			
						
		</div>
		
		
			
		
	 </form>
		
		<div class="row"> 
			<div class="borde color4 col-sm-12"> FOOTER </div>
		
		</div>
		
		
	</div>
  
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <!-- <script src="../js/bootstrap.min.js"></script> -->

	
	<!-- jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- Select2 -->
	<script src="plugins/select2/js/select2.full.min.js"></script>
	<!-- Bootstrap4 Duallistbox -->
	<script src="plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>

	<!-- bootstrap color picker -->
	<script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
	<!-- Tempusdominus Bootstrap 4 -->
	<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
	<!-- Bootstrap Switch -->
	<script src="plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
	<!-- AdminLTE App -->
	<script src="dist/js/adminlte.min.js"></script>
	<!-- AdminLTE for demo purposes -->
	<script src="dist/js/demo.js"></script>
	
	
	<script type="text/javascript" src="js/main.js"></script>


<script>
	window.onload = function(){
		var contador = 0;
		document.getElementById("cmbx_Bodega").onclick = function(){
			contador ++;
			var Cont1 = Math.round(contador /2);
			document.getElementById("mostrar").innerHTML = Cont1;
		}		

	}



</script>


<script> 
	function miFuncion(){

		var Bodega = document.getElementById("cmbx_Bodega").value;
		document.getElementById("tutorial").innerHTML += Bodega + ",";

	}

</script>


<script> 
	function miFuncion1(){
		var suma = 0;
		var Bodega = parseInt(document.getElementById("cmbx_M2").value);
		
		var suma = parseInt(suma+Bodega);
		
		document.getElementById("SuperficieM2").innerHTML = suma  ;

		
		
	}
</script>

<script type="text/javascript">
	document.addEventListener('DOMContentLoaded', function(){
	var suma = 0;
	document.getElementById('cmbx_M2').addEventListener('change', function(){
	suma += parseInt(this.value);
	document.getElementById('sumaM2').innerHTML = suma;
});
});

</script>


<script>
	function solonumeros(e){
		key=e.keyCode || e.which;
		
		teclado=String.fromCharCode(key);
		
		numeros="0123456789";
		
		especiales = "8-34-38-46-188-110-44";
		
		teclado_especial=false;
		
		for(var i in especiales){
			if(key==especiales[i]){
				teclado_especial=true;
				
				
			}
			
		}
		
		if(numeros.indexOf(teclado)==-1 && !teclado_especial){
			return false;
			
			
		}
		
	}


</script>

<script>
function validateDecimal(valor) {
    var RE = /^\d*(\.\d{1})?\d{0,1}$/;
    if (RE.test(valor)) {
        return true;
    } else {
        return false;
    }
}
</script>



<script type="text/javascript">

function filterFloat2(evt,input){
    // Backspace = 8, Enter = 13, ‘0′ = 48, ‘9′ = 57, ‘.’ = 46, ‘-’ = 43
    var key = window.Event ? evt.which : evt.keyCode;    
    var chark = String.fromCharCode(key);
    var tempValue = input.value+chark;
    if(key >= 48 && key <= 57){
        if(filter(tempValue)=== false){
            return false;
        }else{       
            return true;
        }
    }else{
          if(key == 8 || key == 13 || key == 0 ) {     
              return true;              
          }else if(key == 46 || key == 44){
                if(filter(tempValue)=== false){
                    return false;
                }else{       
                    return true;
                }
          }else{
              return false;
          }
    }
}
function filter(__val__){
    var preg = /^([0-9]+\.?[0-9]{0,2})$/; 
    if(preg.test(__val__) === true){
        return true;
    }else{
       return false;
    }
    
}

</script>


<!-- VALIDAR --->





<!-- FIN -->






<script type="text/javascript">
window.onload = function(){
    fecha = new Date();
    texto = document.getElementById("fechaing");
    texto.value = fecha.getDate()+"/"+(fecha.getMonth()+1)+"/"+fecha.getFullYear();
}
</script>


<script>

var obj=document.getElementById('MyDate');
var obj2 = document.getElementById('MyDate2');
var obj3 = document.getElementById('MyDate3');
obj.value = setFormato(new Date());

function AddMes(){
 var fecha = new Date(obj.value);
 fecha.setMonth( fecha.getMonth() + +(obj2.value));
 obj3.value = setFormato(fecha);
}

function setFormato(fecha){
    var day = ("0" + fecha.getDate()).slice(-2);
    var month = ("0" + (fecha.getMonth() + 1)).slice(-2);
    var date = (day)+"-"+(month)+"-"+fecha.getFullYear();
    return date;
}

</script>






  </body>
</html>